﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPISample.Models
{
    public class Customer
    {
        public string CustomerName { get; set; }
        public string Designation { get; set; }
    }
}