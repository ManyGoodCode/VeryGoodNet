# Oxygen-Dapr
一款基于dapr的.netRPC封装。统一了请求编程模型(服务调用/事件/状态&Actor)和服务(基于kestrel router/eventhandle/actorservice提供直接对应用服务的访问)
