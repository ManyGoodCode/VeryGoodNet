﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Oxygen.Server.Kestrel.Interface
{
    public enum MessageType
    {
        Json = 0,
        MessagePack = 1,
        Html = 2
    }
}
