﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oxygen.Client.ServerSymbol.Events
{
    /// <summary>
    /// actor服务接口，需要actor接口集成
    /// </summary>
    public interface IActorService
    {

    }
}
