﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IApplicationService.AccountService.Dtos.Output
{
    public class DefLoginAccountResponse
    {
        public string LoginName { get; set; }
        public string Password { get; set; }
    }
}
