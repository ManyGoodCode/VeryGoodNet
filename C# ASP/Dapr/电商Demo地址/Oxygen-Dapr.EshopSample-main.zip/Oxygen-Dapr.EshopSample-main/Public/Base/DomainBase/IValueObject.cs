﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DomainBase
{
    /// <summary>
    /// 值对象标记
    /// </summary>
    public interface IValueObject
    {

    }
}
