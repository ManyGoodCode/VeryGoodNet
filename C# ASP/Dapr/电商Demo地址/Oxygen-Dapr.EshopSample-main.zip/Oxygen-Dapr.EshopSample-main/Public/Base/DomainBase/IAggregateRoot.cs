﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DomainBase
{
    /// <summary>
    /// 领域聚合根标记
    /// </summary>
    public interface IAggregateRoot
    {

    }
}
