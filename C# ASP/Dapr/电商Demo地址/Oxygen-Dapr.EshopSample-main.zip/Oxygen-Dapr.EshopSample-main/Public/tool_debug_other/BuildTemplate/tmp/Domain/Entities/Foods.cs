using System;
using DomainBase;

namespace Domain.Entities
{
    /// <summary>
    /// ����ʵ��
    /// </summary>
    public class Foods : Entity, IAggregateRoot
    {
        
    }
}
