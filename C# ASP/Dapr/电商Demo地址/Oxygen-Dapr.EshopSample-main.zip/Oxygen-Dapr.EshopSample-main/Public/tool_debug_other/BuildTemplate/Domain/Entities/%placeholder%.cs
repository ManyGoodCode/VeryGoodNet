﻿using System;
using DomainBase;

namespace Domain.Entities
{
    /// <summary>
    /// 领域实体
    /// </summary>
    public class %placeholder% : Entity, IAggregateRoot
    {
        
    }
}
