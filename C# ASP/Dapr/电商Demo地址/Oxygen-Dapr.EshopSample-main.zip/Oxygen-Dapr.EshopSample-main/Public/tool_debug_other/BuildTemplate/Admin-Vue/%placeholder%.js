import request from '@/utils/request'

export function Get%placeholder%List(data) {
  return request({
    url: '/goodsservice/method/%xxx%query/Get%placeholder%List',
    method: 'post',
    data
  })
}
export function Create%placeholder%(data) {
  return request({
    url: '/goodsservice/method/%xxx%usecase/Create%placeholder%',
    method: 'post',
    data
  })
}
export function Delete%placeholder%(data) {
  return request({
    url: '/goodsservice/method/%xxx%usecase/Delete%placeholder%',
    method: 'post',
    data
  })
}
export function Update%placeholder%(data) {
  return request({
    url: '/goodsservice/method/%xxx%usecase/Update%placeholder%',
    method: 'post',
    data
  })
}
