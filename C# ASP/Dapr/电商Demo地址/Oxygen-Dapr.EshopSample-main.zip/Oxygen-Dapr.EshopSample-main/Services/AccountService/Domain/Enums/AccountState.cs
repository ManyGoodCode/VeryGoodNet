﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Enums
{
    /// <summary>
    /// 账号状态
    /// </summary>
    public enum AccountState
    {
        Normal = 0, Locking = 1
    }
}
