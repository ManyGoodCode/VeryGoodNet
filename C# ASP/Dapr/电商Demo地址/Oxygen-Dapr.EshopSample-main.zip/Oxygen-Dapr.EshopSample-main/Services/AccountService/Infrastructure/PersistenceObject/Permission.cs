﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.PersistenceObject
{
    public class Permission : Domain.Entities.Permission
    {

    }
}
