﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OauthService.Github
{
    public class Model
    {
        public string login { get; set; }
        public string avatar_url { get; set; }
        public string name { get; set; }
    }
}
