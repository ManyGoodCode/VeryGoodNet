# .NET Driver Version 2.3.0

This is a minor release consisting of:

1. Bug fixes since 2.2.4 was released
2. Support for .NET Core

An online version of these release notes is available at:

https://github.com/mongodb/mongo-csharp-driver/blob/master/Release%20Notes/Release%20Notes%20v2.3.0.md

The JIRA tickets resolved in this release is available at:

https://jira.mongodb.org/issues/?jql=project%20%3D%20CSHARP%20AND%20fixVersion%20%3D%202.3%20ORDER%20BY%20key%20ASC

Upgrading

We don't believe there are any breaking changes in this release.
