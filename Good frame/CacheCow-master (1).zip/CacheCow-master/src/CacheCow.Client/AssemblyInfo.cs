using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("CacheCow.Client.Tests")]
