﻿namespace CacheCow.Common
{
    public static class ConfigurationKeys
    {
        public static readonly string DoNotEmitCacheCowHeader = "DoNotEmitCachecowHeader";
    }
}
