GET /news/ HTTP/1.1
Host: www.bbc.co.uk
Proxy-Connection: keep-alive
User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Encoding: gzip,deflate,sdch
Accept-Language: en-GB,en-US;q=0.8,en;q=0.6
Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.3
Cookie: BBC-UID=d48e3749dde4af8d789f6a14912023ba9f3f117c1020c1f9bb0b73cfe774ca280Mozilla%2f5%2e0%20%28Windows%20NT%206%2e1%3b%20WOW64%29%20AppleWebKit%2f535%2e1%20%28KHTML%2c%20like%20Gecko%29%20Chrome%2f14%2e0%2e835%2e163%20Safari%2f535%2e1; s1=4E79D4FF5E3F0226; ed=1; BGUID=f47ecb2df2cf65da29e5de29415f29b434627fb530b0c1673ae4589d89e2ce10; s_ev49=%5B%5B%27Direct%2520Load%27%2C%271322156326882%27%5D%2C%5B%27Other%2520Referrers%27%2C%271322571656677%27%5D%2C%5B%27Direct%2520Load%27%2C%271322584456001%27%5D%5D; pulse=1; ckns_policy=111; s_ppv=92; s_cc=true; s_sq=%5B%5BB%5D%5D

