HTTP/1.1 200 OK
Proxy-Connection: Keep-Alive
Connection: Keep-Alive
Transfer-Encoding: chunked
Via: 1.1 GNET06
Expires: Thu, 02 Aug 2012 10:30:01 GMT
Date: Thu, 02 Aug 2012 10:30:01 GMT
Content-Type: text/html
Server: Apache
Vary: Cookie,X-CDN
Cache-Control: max-age=0
Access-Control-Allow-Origin: *
Keep-Alive: timeout=5, max=780

69
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN" "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">

2


6d

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:og="http://opengraphprotocol.org/schema/" xml:lang="en-GB"
b
>
        
6

    
6

    
6

    
3

	
6

    
6

    
6

    
6

    
6

    
6

    
6

    
3

	
6

    
3

	
6

    
3

	
3

	
3

	
6

    
3

	
16

    
        
    
2


3c
<!-- THIS FILE CONFIGURES SHARED HIGHWEB STATIC ASSETS -->


1


1


2


1


1b
<!-- mapping_news.inc -->

33
<!-- THIS FILE CONFIGURES NEWS STATIC ASSETS  -->


1


1


2


38
<!-- THIS FILE CONFIGURES VOTE 2012 STATIC ASSETS  -->


1


1


1


6

    
27
<!-- hi/shared/head_initial.inc -->


2


3

	
2


d


	        
555

        <head profile="http://dublincore.org/documents/dcq-html/">
        <meta http-equiv="X-UA-Compatible" content="IE=8" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>BBC News - Home</title>
        <meta name="Description" content="Visit BBC News for up-to-the-minute news, breaking news, video, audio and feature stories. BBC News provides trusted World and UK news as well as local and regional perspectives. Also entertainment, business, science, technology and health news."/>
                <meta name="OriginalPublicationDate" content="2012/08/02 10:27:05"/>
        <meta name="UKFS_URL" content="/news/"/>
                <meta name="Headline" content="INDEX "/>
        <meta name="IFS_URL" content="/news/"/>
        <meta name="Section" content="Home"/>
        <meta name="contentFlavor" content="INDEX"/>
		                        <meta name="CPS_ID" content="10263779" />
        <meta name="CPS_SITE_NAME" content="BBC News" />
        <meta name="CPS_SECTION_PATH" content="Front page" />
        <meta name="CPS_ASSET_TYPE" content="IDX" />
        <meta name="CPS_PLATFORM" content="HighWeb" />
        <meta name="CPS_AUDIENCE" content="Domestic" />
        
                
				<meta name="bbcsearch_noindex" content="atom"/>
		
        <link rel="canonical" href="
14
http://www.bbc.co.uk
15c
/news/" />
       	        		<link rel="alternate" hreflang="en" href="http://www.bbc.com/news/" />
		<link rel="alternate" hreflang="en-gb" href="http://www.bbc.co.uk/news/" />
				        
        							<link href="http://feeds.bbci.co.uk/news/rss.xml" rel="alternate" type="application/rss+xml" title="BBC News - Home" />
							
        
23
<!-- hi/news/head_first.inc -->


b
 
        
14

<!-- PULSE_ENABLED:
7
yes -->
1


2


2


2


2


2


2


2


2


2


2


2


2


2


2


2


2


2


2


2


2


2


4



3

	
3

	
3

	
4

		
4

		
3

	
2


4



3

	
4

		
5

			
6

				
7

					
7

					
7

					
7

					
6

				
6

				
a
				
				
9
			
				
9
			
				
9
			
				
b
					
				
e
		
				
				
7
	
				
7
	
				
7
	
				
7
	
				
7
	
				
7
	
				
7
	
				
7
	
				
18
					
											
				
12

				
				
				
a
				
				
9
				
			
5

			
5

			
7
			
		
5
	
		
3

	
6

	
	
6

	
	
3

	
3

	
3

	
3

	
3

	
3

	
3

	
3

	
3

	
4

		
3

	
3

	
3
	

4



2


1


2

	
3

		
2954


  
   <meta http-equiv="X-UA-Compatible" content="IE=8" />  
  <link rel="schema.dcterms" href="http://purl.org/dc/terms/" />  <link rel="index" href="http://www.bbc.co.uk/a-z/" title="A to Z" /> <link rel="help" href="http://www.bbc.co.uk/help/" title="BBC Help" /> <link rel="copyright" href="http://www.bbc.co.uk/terms/" title="Terms of Use" /> <link rel="icon" href="http://www.bbc.co.uk/favicon.ico" type="image/x-icon" />  <meta name="viewport" content="width = 974" /> 

 <link rel="stylesheet" type="text/css" href="http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5/style/main.css"  />      <script type="text/javascript"> if (! window.gloader) { window.gloader = [ "glow", {map: "http://node1.bbcimg.co.uk/glow/glow/map.1.7.7.js"}]; } </script>  <script type="text/javascript" src="http://node1.bbcimg.co.uk/glow/gloader.0.1.6.js"></script>   <script type="text/javascript" src="http://static.bbci.co.uk/frameworks/requirejs/0.11.1/sharedmodules/require.js"></script> <script type="text/javascript">  bbcRequireMap = {"jquery-1":"http://static.bbci.co.uk/frameworks/jquery/0.1.8/sharedmodules/jquery-1.6.2", "jquery-1.4":"http://static.bbci.co.uk/frameworks/jquery/0.1.8/sharedmodules/jquery-1.4", "swfobject-2":"http://static.bbci.co.uk/frameworks/swfobject/0.1.3/sharedmodules/swfobject-2", "demi-1":"http://static.bbci.co.uk/frameworks/demi/0.9.8/sharedmodules/demi-1", "gelui-1":"http://static.bbci.co.uk/frameworks/gelui/0.9.7/sharedmodules/gelui-1", "cssp!gelui-1/overlay":"http://static.bbci.co.uk/frameworks/gelui/0.9.7/sharedmodules/gelui-1/overlay.css", "istats-1":"http://static.bbci.co.uk/frameworks/istats/0.9.1/modules/istats-1", "relay-1":"http://static.bbci.co.uk/frameworks/relay/0.2.4/sharedmodules/relay-1", "clock-1":"http://static.bbci.co.uk/frameworks/clock/0.1.5/sharedmodules/clock-1", "canvas-clock-1":"http://static.bbci.co.uk/frameworks/clock/0.1.5/sharedmodules/canvas-clock-1", "cssp!clock-1":"http://static.bbci.co.uk/frameworks/clock/0.1.5/sharedmodules/clock-1.css", "jssignals-1":"http://static.bbci.co.uk/frameworks/jssignals/0.3.3/modules/jssignals-1", "jcarousel-1":"http://static.bbci.co.uk/frameworks/jcarousel/0.1.8/modules/jcarousel-1"}; require({ baseUrl: 'http://static.bbci.co.uk/', paths: bbcRequireMap, waitSeconds: 30 }); </script>      <script type="text/javascript" src="http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5/script/barlesque.js"></script>
 <script type="text/javascript">/*<![CDATA[*/ if (typeof bbccookies_flag === 'undefined') { bbccookies_flag = 'ON'; } showCTA_flag = true; cta_enabled = (showCTA_flag && (bbccookies_flag === 'ON') ); (function(){var e="ckns_policy",m="Thu, 01 Jan 1970 00:00:00 GMT",k={ads:true,personalisation:true,performance:true,necessary:true};function f(p){if(f.cache[p]){return f.cache[p]}var o=p.split("/"),q=[""];do{q.unshift((o.join("/")||"/"));o.pop()}while(q[0]!=="/");f.cache[p]=q;return q}f.cache={};function a(p){if(a.cache[p]){return a.cache[p]}var q=p.split("."),o=[];while(q.length&&"|co.uk|com|".indexOf("|"+q.join(".")+"|")===-1){if(q.length){o.push(q.join("."))}q.shift()}f.cache[p]=o;return o}a.cache={};function i(o,t,p){var z=[""].concat(a(window.location.hostname)),w=f(window.location.pathname),y="",r,x;for(var s=0,v=z.length;s<v;s++){r=z[s];for(var q=0,u=w.length;q<u;q++){x=w[q];y=o+"="+t+";"+(r?"domain="+r+";":"")+(x?"path="+x+";":"")+(p?"expires="+p+";":"");bbccookies.set(y,true)}}}window.bbccookies={_setEverywhere:i,cookiesEnabled:function(){var o="ckns_testcookie"+Math.floor(Math.random()*100000);this.set(o+"=1");if(this.get().indexOf(o)>-1){g(o);return true}return false},set:function(o){return document.cookie=o},get:function(){return document.cookie},_setPolicy:function(o){return h.apply(this,arguments)},readPolicy:function(o){return b.apply(this,arguments)},_deletePolicy:function(){i(e,"",m)},isAllowed:function(){return true},_isConfirmed:function(){return c()!==null},_acceptsAll:function(){var o=b();return o&&!(j(o).indexOf("0")>-1)},_getCookieName:function(){return d.apply(this,arguments)},_showPrompt:function(){return(!this._isConfirmed()&&window.cta_enabled&&this.cookiesEnabled()&&!window.bbccookies_disable)}};bbccookies._getPolicy=bbccookies.readPolicy;function d(p){var o=(""+p).match(/^([^=]+)(?==)/);return(o&&o.length?o[0]:"")}function j(o){return""+(o.ads?1:0)+(o.personalisation?1:0)+(o.performance?1:0)}function h(r){if(typeof r==="undefined"){r=k}if(typeof arguments[0]==="string"){var o=arguments[0],q=arguments[1];if(o==="necessary"){q=true}r=b();r[o]=q}else{if(typeof arguments[0]==="object"){r.necessary=true}}var p=new Date();p.setYear(p.getFullYear()+1);p=p.toUTCString();bbccookies.set(e+"="+j(r)+";domain=bbc.co.uk;path=/;expires="+p+";");bbccookies.set(e+"="+j(r)+";domain=bbc.com;path=/;expires="+p+";");return r}function l(o){if(o===null){return null}var p=o.split("");return{ads:!!+p[0],personalisation:!!+p[1],performance:!!+p[2],necessary:true}}function c(){var o=new RegExp("(?:^|; ?)"+e+"=(\\d\\d\\d)($|;)"),p=document.cookie.match(o);if(!p){return null}return p[1]}function b(o){var p=l(c());if(!p){p=k}if(o){return p[o]}else{return p}}function g(o){return document.cookie=o+"=;expires="+m+";"}function n(){var o='<script type="text/javascript" src="http://static.bbci.co.uk/frameworks/bbccookies/0.5.4/script/bbccookies.js"><\/script>';if(window.bbccookies_flag==="ON"&&!bbccookies._acceptsAll()&&!window.bbccookies_disable){document.write(o)}}n()})(); /*]]>*/</script>   <script type="text/javascript"> require({ paths: { 'lately-1': 'http://static.bbci.co.uk/frameworks/panelpromos/0.1.4/scripts/lately-1', 'mustache-1': 'http://static.bbci.co.uk/frameworks/panelpromos/0.1.4/scripts/mustache-1' } }); window.lately = (location.protocol === 'http:'); </script> <script type="text/mustache" id="lately-promo-template"><![CDATA[ <div class="blq-panel-container panel-paneltype-olympics"> {{#header}} <div class="panel-header"> <h2> <a href="{{url}}"> {{#image}}<img src="{{image}}" alt="{{text}}" width="91" height="28">{{/image}}{{^image}}{{text}}{{/image}}</a> </h2> <a href="{{url}}" class="panel-header-link">{{subtext}}</a> </div> {{/header}} <div class="panel-component panel-links"> <ul> {{#links}} <li class="panel-first"> <a href="{{url}}" class="panel-theme-{{theme}}"> {{text}} </a> </li> {{/links}} </ul> </div> {{#promos}} <div class="panel-component panel-promo-1 panel-clickable {{format}} panel-theme-{{theme}}"> <h3> <a href="{{url}}"> {{text}} <img src="{{image.url}}" alt="{{image.alt}}" width="112" height="63"> </a> </h3> <p> <a href="{{url}}"> {{subtext}} </a> </p> </div> {{/promos}} </div> ]]></script> <script type="text/mustache" id="lately-error-template"><![CDATA[ <div class="panel-error"> <h2>Sorry</h2> <p>This content is temporarily unavailable due to a technical problem.</p> <p><a href="/2012/" class="panel-header-link">2012 Home</a></p> </div> ]]></script> <script type="text/mustache" id="lately-loading-template"><![CDATA[ <div class="panel-loading"><span>Loading</span></div> ]]></script>   
<!--[if IE 6]>
        <script type="text/javascript">
        try {
            document.execCommand("BackgroundImageCache",false,true);
        } catch(e) {}
    </script>
        <style type="text/css">
        /* Use filters for IE6 */
        #blq-blocks a {
            background-image: none;
            filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5//img/blq-blocks_white_alpha.png', sizingMethod='image');
        }
        .blq-masthead-focus #blq-blocks a,
        .blq-mast-text-dark #blq-blocks a {
            background-image: none;
            filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5//img/blq-blocks_grey_alpha.png', sizingMethod='image');
        }
        #blq-nav-search button span {
            background-image: none;
            filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5//img/blq-search_white_alpha.png', sizingMethod='image');
        }
        .blq-masthead-focus #blq-nav-search button span,
        .blq-mast-text-dark #blq-nav-search button span {
            background-image: none;
            filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5//img/blq-search_grey_alpha.png', sizingMethod='image');
        }
        #blq-nav-promo span {
            background-image: none;
            filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5//img/promo_olympics_light.png', sizingMethod='image');
        }
        .blq-masthead-focus #blq-nav-promo span {
            background-image: none;
            filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5//img/promo_olympics_dark.png', sizingMethod='image');
        }
    </style>
<![endif]-->

<!--[if (IE 7])|(IE 8)>
    <style type="text/css">
        .blq-clearfix {
            display: inline-block;
        }
    </style>
<![endif]-->

<script type="text/javascript">
     blq.setEnvironment('live');  if (blq.setLabel) blq.setLabel('searchSuggestion', "Search");  </script>

 <script type="text/javascript" src="http://static.bbci.co.uk/frameworks/pulsesurvey/0.7.0/script/pulse.js"></script>  <script type="text/javascript" src="http://www.bbc.co.uk/survey/pulse/conf.js"></script>  <script type="text/javascript"> pulse.translations.intro = "We are always looking to improve the site and your opinions count."; pulse.translations.question = "Do you have a few minutes to tell us what you think about this site?"; pulse.translations.accept = "Yes"; pulse.translations.reject = "No";  </script> <link rel="stylesheet" href="http://static.bbci.co.uk/frameworks/pulsesurvey/0.7.0/style/pulse.css" type="text/css"/> <!--[if gte IE 6]> <style type="text/css"> .pulse-pop li{display:inline;width:40px} </style> <![endif]--> <!--[if IE 6]> <style type="text/css"> .pulse-pop li{display:inline;width:40px} .pulse-pop #pulse-q{background:url(http://static.bbci.co.uk/frameworks/pulsesurvey/0.7.0/img/pulse_bg.gif) no-repeat} .pulse-pop #pulse-a{background:url(http://static.bbci.co.uk/frameworks/pulsesurvey/0.7.0/img/pulse_bg.gif) bottom no-repeat;} </style> <![endif]--> <!--[if IE 7]> <style type="text/css">  .pulse-pop #pulse-a{zoom:1} </style> <![endif]-->               
2

	
1


e

        
		
60
<!-- shared/head -->
<meta http-equiv="imagetoolbar" content="no" />
<!--[if !(lt IE 6)]>
   
2e
	<link rel="stylesheet" type="text/css" href="
1e
http://news.bbcimg.co.uk/view/
26
3_0_0/cream/hi/shared/type.css" />


40

		<link rel="stylesheet" type="text/css" media="screen" href="
1e
http://news.bbcimg.co.uk/view/
26
3_0_0/cream/hi/shared/global.css" />

2b


	<link rel="stylesheet" type="text/css"
e
 media="print"
7
 href="
18
http://news.bbcimg.co.uk
6
/view/
b
3_0_0/cream
77
/hi/shared/print.css" />

	<link rel="stylesheet" type="text/css" media="screen and (max-device-width: 976px)" href="
1e
http://news.bbcimg.co.uk/view/
29
3_0_0/cream/hi/shared/mobile.css" />
	

4



2f

<link rel="stylesheet" type="text/css" href="
1e
http://news.bbcimg.co.uk/view/
35
3_0_0/cream/hi/shared/components/components.css" />

25

<![endif]-->
<!--[if !IE]>-->
   
2e
	<link rel="stylesheet" type="text/css" href="
1e
http://news.bbcimg.co.uk/view/
26
3_0_0/cream/hi/shared/type.css" />


40

		<link rel="stylesheet" type="text/css" media="screen" href="
1e
http://news.bbcimg.co.uk/view/
26
3_0_0/cream/hi/shared/global.css" />

2b


	<link rel="stylesheet" type="text/css"
e
 media="print"
7
 href="
18
http://news.bbcimg.co.uk
6
/view/
b
3_0_0/cream
77
/hi/shared/print.css" />

	<link rel="stylesheet" type="text/css" media="screen and (max-device-width: 976px)" href="
1e
http://news.bbcimg.co.uk/view/
29
3_0_0/cream/hi/shared/mobile.css" />
	

4



2f

<link rel="stylesheet" type="text/css" href="
1e
http://news.bbcimg.co.uk/view/
35
3_0_0/cream/hi/shared/components/components.css" />

1eb

<!--<![endif]-->
<script type="text/javascript">
/*<![CDATA[*/
gloader.load(["glow","1","glow.dom"],{onLoad:function(glow){glow.dom.get("html").addClass("blq-js")}});
gloader.load(["glow","1","glow.dom"],{onLoad:function(glow){glow.ready(function(){if (glow.env.gecko){var gv = glow.env.version.split(".");for (var i=gv.length;i<4;i++){gv[i]=0;}if((gv[0]==1 && gv[1]==9 && gv[2]==0)||(gv[0]==1 && gv[1]<9)||(gv[0]<1)){glow.dom.get("body").addClass("firefox-older-than-3-5");}}});}});

73

window.disableFacebookSDK=true;
if (window.location.pathname.indexOf('+')>=0){window.disableFacebookSDK=true;}

16

/*]]>*/
</script>

24
<script type="text/javascript" src="
4f
http://news.bbcimg.co.uk/js/locationservices/locator/v4_0/locator.js"></script>
2


1


62
<script type="text/javascript" src="http://news.bbcimg.co.uk/js/core/3_3_1/bbc_fmtj.js"></script>

1


46
<script type="text/javascript">
<!--
	bbc.fmtj.page = {
		serverTime: 
21
1343903401000,
		editionToServe: 
1
'
9
domestic'
11
,
		queryString: 
4
null
e
,
		referrer: 
4
null
d
,
		section: 
1
'
b
front-page'
11
,
		sectionPath: 
2
'/
b
Front page'
e
,
		siteName: 
1
'
9
BBC News'
11
,
		siteToServe: 
1
'
5
news'
11
,
		siteVersion: 
1
'
6
cream'
d
,
		storyId: 
1
'
8
10263779
1
'
f
,
		assetType: 
1
'
6
index'
9
,
		uri: 
1
'
7
/news/'
d
,
		country: 
1
'
3
gb'
e
,
		masthead: 
5
false
f
,
		adKeyword: 
4
null
15
,
		templateVersion: 
1
'
5
v1_0'
11

	}
-->
</script>
1


6b
<script type="text/javascript" src="http://news.bbcimg.co.uk/js/common/3_2_1/bbc_fmtj_common.js"></script>

1


1


67
<script type="text/javascript">$useMap({map:"http://news.bbcimg.co.uk/js/map/map_0_0_32.js"});</script>
2b

<script type="text/javascript">$loadView("
68
0.0",["bbc.fmtj.view"]);</script>
<script type="text/javascript">$render("livestats-heatmap");</script>

1


1


70
<script type="text/javascript" src="http://news.bbcimg.co.uk/js/config/apps/4_7_1/bbc_fmtj_config.js"></script>

1


1


751


<script type="text/javascript">
    //<![CDATA[
        require(['jquery-1'], function($){
            
            // set up EMP once it's loaded
            var setUp = function(){
                // use our own pop out page
        	    embeddedMedia.setPopoutUrl('/player/emp/2_0_55/popout/pop.stm');

        	    // store EMP's notifyParent function
        	    var oldNotifyParent = embeddedMedia.console.notifyParent;
        	    // use our own to add livestats to popout
        	    embeddedMedia.console.notifyParent = function(childWin){
        	        oldNotifyParent(childWin);
        	        // create new live stats url
                    var liveStatsUrl = bbc.fmtj.av.emp.liveStatsForPopout($('#livestats').attr('src'));
                    var webBug = $('<img />', {
                                     id:  'livestats',
                                     src: liveStatsUrl
                                 });
                    // append it to popout
                    $(childWin.document).find('body').append(webBug);
                }
            }
                
            // check if console is available to manipulate
            if(window.embeddedMedia && window.embeddedMedia.console){
                setUp();
            }
            // otherwise emp is still loading, so add event listener
            else{
                $(document).bind('empReady', function(){
                    setUp();
                });
            }
        });
    //]]>
</script>


		
	<!-- get BUMP from cdn -->
    <script type="text/javascript" src="http://emp.bbci.co.uk/emp/bump?emp=worldwide&amp;enableClear=1"></script>

<!-- load glow and required modules -->
<script type="text/javascript">
    //<![CDATA[
        gloader.load(['glow', '1', 'glow.dom']);
    //]]>
</script>



11c

	<!-- pull in our emp code -->
	<script type="text/javascript" src="http://news.bbcimg.co.uk/js/app/av/emp/2_0_55/emp.js"></script>
	<!-- pull in compatibility.js -->
	<script type="text/javascript" src="http://news.bbcimg.co.uk/js/app/av/emp/2_0_55/compatibility.js"></script>

38


<script type="text/javascript">
	//<![CDATA[
	    
a

	
	    
b

	        
7

	    
a

	
	    
b

	        
7

	    
2c

	
	    // set site specific config
	    
29

	        bbc.fmtj.av.emp.configs.push('
e
news');
	    
22d

	    
	    // when page loaded, write all created emps
	    glow.ready(function(){
			if(typeof bbcdotcom !== 'undefined' && bbcdotcom.av && bbcdotcom.av.emp){
				bbcdotcom.av.emp.configureAll();
			}
			embeddedMedia.each(function(emp){
				emp.set('enable3G', true);
				emp.setMediator('href', '{protocol}://{host}/mediaselector/5/select/version/2.0/mediaset/{mediaset}/vpid/{id}');						
			});
			embeddedMedia.writeAll();
	        // mark the emps as loaded
	        bbc.fmtj.av.emp.loaded = true;
			
			
	    });
	//]]>
</script>
2a

<!-- Check for advertising testing -->

36

<meta name="viewport" content="width = 996" />



a

        
55
<!-- shared/head_index -->
<!-- THESE STYLESHEETS VARY ACCORDING TO PAGE CONTENT -->

3d

<link rel="stylesheet" type="text/css" media="screen" href="
1e
http://news.bbcimg.co.uk/view/
2b
3_0_0/cream/hi/shared/layout/index.css" />

43


<!-- js index view -->
<script type="text/javascript">$loadView("
2d
0.0",["bbc.fmtj.view.news.index"]);</script>

a

        
272
<!-- #CREAM hi news domestic head.inc -->

<script type="text/javascript">
	if(undefined !== bbc && undefined !== bbc.fmtj){
		bbc.fmtj.makeNewsSurveyConfig = function(surveyId,probabilityRate){	
			if(surveyId !== undefined){
				pulse.localSurvey = {
					'active' : true,
					'URLFormat' : 'http://ecustomeropinions.com/survey/survey.php?sid='+ surveyId,
					'probability' : probabilityRate,
					'translations' : {
						'intro' : 'We are always looking to improve the site and your opinions count.',
						'question' : 'Do you have a few minutes to tell us what you think about this site?'
					}				
				}
							
				
1d
			
			}
		};
	}
	</script>


6
	
    
1


2



58
  
                            <!-- is suitable for ads adding isadvertise ... -->
			
2


2


2


4



2


2


5

			
3
 

5

			
2


8


    
5


	
4

		
4

		
3

	
83a


    <script type="text/javascript">
    /*<![CDATA[*/
    if(typeof(bbcdotcom) == 'undefined') { var bbcdotcom = {}; }
    bbcdotcom.createObject = function(namespace){
        var names   = namespace.split('.'),
            next    = '',
            i       = 0,
            len     = names.length;
        for(i; i < len; i++){
            if('' !== next) {
                next = ('object' === typeof next[names[i]]) ? next[names[i]] : next[names[i]] = {};
            } else {
                next = ('object' === typeof window[names[i]]) ? window[names[i]] : window[names[i]] = {};
            }
        }
    };
    bbcdotcom.createObject('bbcdotcom.stats');
    /*]]>*/
    </script>

	<meta name="application-name" content="BBC"/>
	<meta name="msapplication-tooltip" content="Explore the BBC, for latest news, sport and weather, TV &amp; radio schedules and highlights, with nature, food, comedy, children's programmes and much more"/>
	<meta name="msapplication-starturl" content="http://www.bbc.com"/>
	<meta name="msapplication-window" content="width=1024;height=768"/>
	<meta name="msapplication-task" content="name=BBC Home;action-uri=http://www.bbc.com;icon-uri=http://news.bbcimg.co.uk/shared/img/bbccom/favicon_16.ico" />
	<meta name="msapplication-task" content="name=BBC News;action-uri=http://www.bbc.com/news/;icon-uri=http://news.bbcimg.co.uk/shared/img/bbccom/favicon_16.ico" />
	<meta name="msapplication-task" content="name=BBC Sport;action-uri=http://www.bbc.com/sport/;icon-uri=http://news.bbcimg.co.uk/shared/img/bbccom/favicon_16.ico" />
	<meta name="msapplication-task" content="name=BBC Future;action-uri=http://www.bbc.com/future/;icon-uri=http://news.bbcimg.co.uk/shared/img/bbccom/favicon_16.ico" />
	<meta name="msapplication-task" content="name=BBC Travel;action-uri=http://www.bbc.com/travel/;icon-uri=http://news.bbcimg.co.uk/shared/img/bbccom/favicon_16.ico" />
	<meta name="msapplication-task" content="name=BBC Weather;action-uri=http://www.bbc.com/weather/;icon-uri=http://news.bbcimg.co.uk/shared/img/bbccom/favicon_16.ico" />

	
4



2


c

        		
20
<!-- hi/news/head_last.inc -->

3e

<link rel="stylesheet" type="text/css" media="screen" href="
1e
http://news.bbcimg.co.uk/view/
23
1_4_35/cream/hi/news/skin.css" />

2


25

<link rel="apple-touch-icon" href="
1d
http://news.bbcimg.co.uk/img/
1ed
1_0_1/cream/hi/news/iphone.png"/> 
<script type="text/javascript">
require(["jquery-1", "istats-1"], function ($, istats) {
    $(function() {
        istats.track('external', {region: $('.story-body'), linkLocation : 'story-body'});
        istats.track('external', {region: $('.story-related .related-links'), linkLocation : 'related-links'});
        istats.track('external', {region: $('.story-related .newstracker-list'), linkLocation : 'newstracker'});
    });
});
</script>


2


2


2


3

	
8

    		
3

	
4
	
	
7

    	
5

   
2


1b

<!-- CPS COMMENT STATUS: 
b
false -->

5e

	   <!--Rendered by 5756004 -->
    </head>

        	    <!--[if lte IE 6]><body class="
4
news
46
 ie disable-wide-advert"><![endif]-->
    <!--[if IE 7]><body class="
4
news
47
 ie7 disable-wide-advert"><![endif]-->
    <!--[if IE 8]><body class="
4
news
49
 ie8 disable-wide-advert"><![endif]-->
    <!--[if !IE]>--><body class="
4
news
da
 disable-wide-advert"><!--<![endif]-->
	<div class="livestats-web-bug"><img alt="" id="livestats" src="http://stats.bbc.co.uk/o.gif?~RS~s~RS~News~RS~t~RS~HighWeb_Index~RS~i~RS~0~RS~p~RS~99854~RS~a~RS~Domestic~RS~u~RS~
6
/news/
9
~RS~r~RS~
6
(none)
9
~RS~q~RS~
9
~RS~z~RS~
2
01
17
~RS~"/></div>
        
2

	
2

	
15


   <!-- ISTATS -->

2



5

    
1


3




2



60

 <script type="text/javascript">/*<![CDATA[*/ bbcFlagpoles_istats = 'ON'; istatsTrackingUrl = '
8d6
//sa.bbc.co.uk/bbc/bbc/s?name=news.page&cps_asset_id=10263779&page_type=index&section=front-page&app_version=6.2.96-RC7&first_pub=2010-06-10T14:18:30+00:00&last_editorial_update=2012-08-02T10:27:05+00:00&title=&comments_box=false&cps_media_type=&cps_media_state=&app_type=web&ml_name=SSI&ml_version=0.9.1&language=en-GB'; (function() { if ( /\bIDENTITY=/.test(document.cookie) ) { istatsTrackingUrl += '&bbc_identity=1'; } var c = (document.cookie.match(/\bckns_policy=(\d\d\d)/)||[]).pop() || ''; istatsTrackingUrl += '&bbc_mc=' + (c? 'ad'+c.charAt(0)+'ps'+c.charAt(1)+'pf'+c.charAt(2) : 'not_set'); if ( /\bckns_policy=\d\d0/.test(document.cookie) ) { istatsTrackingUrl += '&ns_nc=1'; } })(); /*]]>*/</script>  <!-- Begin iStats 20100118 (UX-CMC 1.1009.3) --> <script type="text/javascript">/*<![CDATA[*/ (function() { window.istats || (istats = {}); var cookieDisabled = (document.cookie.indexOf('NO-SA=') != -1), hasCookieLabels = (document.cookie.indexOf('sa_labels=') != -1), hasClickThrough = /^#sa-(.*?)(?:-sa(.*))?$/.test(document.location.hash), runSitestat = !cookieDisabled && !hasCookieLabels && !hasClickThrough && !istats._linkTracked; if (runSitestat && bbcFlagpoles_istats === 'ON') { sitestat(istatsTrackingUrl); } function sitestat(n){var j=document,f=j.location,b="";if(j.cookie.indexOf("st_ux=")!=-1){var k=j.cookie.split(";");var e="st_ux",h=document.domain,a="/";if(typeof ns_!="undefined"&&typeof ns_.ux!="undefined"){e=ns_.ux.cName||e;h=ns_.ux.cDomain||h;a=ns_.ux.cPath||a}for(var g=0,f=k.length;g<f;g++){var m=k[g].indexOf("st_ux=");if(m!=-1){b="&"+unescape(k[g].substring(m+6))}}document.cookie=e+"=; expires="+new Date(new Date().getTime()-60).toGMTString()+"; path="+a+"; domain="+h}ns_pixelUrl=n;n=ns_pixelUrl+"&ns__t="+(new Date().getTime())+"&ns_c="+((j.characterSet)?j.characterSet:j.defaultCharset)+"&ns_ti="+escape(j.title)+b+"&ns_jspageurl="+escape(f&&f.href?f.href:j.URL)+"&ns_referrer="+escape(j.referrer);if(n.length>2000&&n.lastIndexOf("&")){n=n.substring(0,n.lastIndexOf("&")+1)+"ns_cut="+n.substring(n.lastIndexOf("&")+1,n.lastIndexOf("=")).substring(0,40)}(j.images)?new Image().src=n:j.write('<p><i'+'mg src="'+n+'" height="1" width="1" alt="" /></p>')}; })(); /*]]>*/</script> <noscript><p class="blq-hide"><img src="
efc
//sa.bbc.co.uk/bbc/bbc/s?name=news.page&amp;cps_asset_id=10263779&amp;page_type=index&amp;section=front-page&amp;app_version=6.2.96-RC7&amp;first_pub=2010-06-10T14:18:30+00:00&amp;last_editorial_update=2012-08-02T10:27:05+00:00&amp;title=&amp;comments_box=false&amp;cps_media_type=&amp;cps_media_state=&amp;app_type=web&amp;ml_name=SSI&amp;ml_version=0.9.1&amp;language=en-GB" height="1" width="1" alt="" /></p></noscript> <!-- End iStats (UX-CMC) -->   <div id="blq-global"> <div id="blq-pre-mast" xml:lang="en-GB"> <!-- Pre mast -->  </div> </div>  <script type="text/html" id="blq-bbccookies-tmpl"><![CDATA[ <div id="bbccookies-prompt"> <h2> Cookies on the BBC website </h2> <p> We use cookies to ensure that we give you the best experience on our website. If you continue without changing your settings, we'll assume that you are happy to receive all cookies on the BBC website. However, if you would like to, you can <a href="/privacy/cookies/managing/cookie-settings.html">change your cookie settings</a> at any time. </p> <ul> <li id="bbccookies-continue"> <button type="button" id="bbccookies-continue-button">Continue</button> </li> <li id="bbccookies-more"><a href="/privacy/cookies/bbc">Find out more</a></li></ul> </div> ]]></script> <script type="text/javascript">/*<![CDATA[*/ (function(){if(bbccookies._showPrompt()){var i=document,b=i.getElementById("blq-pre-mast"),f=i.getElementById("blq-global"),h=i.getElementById("blq-container"),c=i.getElementById("blq-bbccookies-tmpl"),a,g,e;if(b&&i.createElement){a=i.createElement("div");a.id="bbccookies";e=c.innerHTML;e=e.replace("<"+"![CDATA[","").replace("]]"+">","");a.innerHTML=e;if(f){f.insertBefore(a,b)}else{h.insertBefore(a,b)}g=i.getElementById("bbccookies-continue-button");g.onclick=function(){a.parentNode.removeChild(a);return false};bbccookies._setPolicy()}}})(); /*]]>*/</script>  <div id="blq-masthead" class="blq-clearfix blq-mast-bg-transparent-light blq-lang-en-GB blq-ltr"> <span id="blq-mast-background"><span></span></span>  <div id="blq-mast" class="blq-rst blq-has-promo">  <div id="blq-mast-bar" class="blq-masthead-container blq-journalism-domestic"> <div id="blq-blocks"> <a href="http://www.bbc.co.uk/" hreflang="en-GB"> <abbr title="British Broadcasting Corporation" class="blq-home"> <img src="http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5/img/blq-blocks_grey_alpha.png" alt="BBC" width="84" height="24" /> </abbr> </a> </div> <div id="blq-acc-links"> <h2 id="page-top">Accessibility links</h2> <ul>  <li><a href="#main-content">Skip to content</a></li>  <li><a href="#blq-local-nav">Skip to local navigation</a></li>  <li><a href="http://www.bbc.co.uk/accessibility/">Accessibility Help</a></li> </ul> </div> <div id="blq-sign-in" class="blq-gel">  </div> <div id="blq-nav"> <h2>bbc.co.uk navigation</h2>     <ul id="blq-nav-main">   <li id="blq-nav-news"> <a href="http://www.bbc.co.uk/news/">News</a> </li>    <li id="blq-nav-sport"> <a href="http://www.bbc.co.uk/sport/">Sport</a> </li>    <li id="blq-nav-weather"> <a href="http://www.bbc.co.uk/weather/">Weather</a> </li>    <li id="blq-nav-iplayer"> <a href="http://www.bbc.co.uk/iplayer/">iPlayer</a> </li>    <li id="blq-nav-tv"> <a href="http://www.bbc.co.uk/tv/">TV</a> </li>    <li id="blq-nav-radio"> <a href="http://www.bbc.co.uk/radio/">Radio</a> </li>    <li id="blq-nav-more"> <a href="http://www.bbc.co.uk/a-z/">More&hellip;</a> </li>    <li id="blq-nav-promo"> <a href="/2012/"> <span> <img src="http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5/img/promo_olympics_dark.png" alt="Olympics" width="51" height="24" /> </span> London 2012 </a> </li>  </ul>   <div id="blq-nav-search"> <form method="get" action="http://search.bbc.co.uk/search" accept-charset="utf-8" id="blq-search-form"> <div>  <input type="hidden" name="go" value="toolbar" />  
1c
<input type="hidden" value="
29
http://www.bbc.co.uk/news/" name="uri" />
299
    <input type="hidden" name="scope" value="news" />  <label for="blq-search-q" class="blq-hide">Search term:</label> <input id="blq-search-q" type="text" name="q" value="" maxlength="128" /> <button id="blq-search-btn" type="submit"><span><img src="http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5/img/blq-search_grey_alpha.png" width="13" height="13" alt="Search"/></span></button> </div> </form> </div>  </div> </div> </div> </div> <div id="blq-container-outer" class="blq-journalism-domestic blq-ltr" >  <div id="blq-container" class="blq-lang-en-GB"> <div id="blq-container-inner" xml:lang="en-GB">   <div id="blq-main" class="blq-clearfix">   
2

	
1


11a

                               	    	    
		<div class="front-page  has-ticker ">
			<div id="header-wrapper">
						  
			  		  
    		      			      				  <h1 id="header">
    			      	            <a rel="index" href="http://www.bbc.co.uk/news/"><img alt="BBC News" src="
18
http://news.bbcimg.co.uk
5
/img/
b
1_0_1/cream
179
/hi/news/news-blocks.gif" /></a>
    	                	            		    	            	<span class="section-updated">    
	    	                    <span class="date">2 August 2012</span>
<span class="time-text">Last updated at </span><span class="time">11:27</span>
	    	                </span>
						    	            		   		      				  </h1>
    			  			  			  
			  
fc

		                    	  				    <a href="http://feeds.bbci.co.uk/news/rss.xml" id="rss-alternative">
    				  RSS<span class="gvl3-icon gvl3-icon-rss"> feed</span>
    			     </a>
                                  			  
			
			  	            
be3
<div id="blq-local-nav">
 	            <ul id="nav" class="nav">
                	
        	        		                	
        	        		<li class="first-child selected"><a href="/news/">Home</a></li>
        		        		                            	
        	        	        	
        	            	<li><a href="/news/world/">World</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/uk/">UK</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/england/">England</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/northern_ireland/">N. Ireland</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/scotland/">Scotland</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/wales/">Wales</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/business/">Business</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/politics/">Politics</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/health/">Health</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/education/">Education</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/science_and_environment/">Sci/Environment</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/technology/">Technology</a></li>
                            	
        	        	        	
        	            	<li><a href="/news/entertainment_and_arts/">Entertainment &amp; Arts</a></li>
                            </ul> 
        
	    	      <ul id="sub-nav" class="nav"> 
	        	        			        	        	
	        		            	<li class="first-child "><a href="/news/video_and_audio/video/">Video &amp; Audio</a></li>
	            	        	        		        	
	        		            	<li><a href="/news/magazine/">Magazine</a></li>
	            	        	        		        	
	        		            	<li><a href="http://www.bbc.co.uk/blogs/theeditors/">Editors' Blog</a></li>
	            	        	        		        	
	        		            	<li><a href="/news/in_pictures/">In Pictures</a></li>
	            	        	        		        	
	        		            	<li><a href="/news/also_in_the_news/">Also in the News</a></li>
	            	        	        		        	
	        		            	<li><a href="/news/have_your_say/">Have Your Say</a></li>
	            	        	        		        	
	        		            	<li><a href="/news/special_reports/">Special Reports</a></li>
	            	        	      </ul> 
	    	</div>

43

			  			  
	        </div>
	        <!-- START CPS_SITE CLASS: 
8
domestic
30
 -->
	        <div id="content-wrapper" class="
8
domestic
31
">
			
					<div class="advert">
													
43

											</div>
				
	            <!-- START CPS_SITE CLASS: 
5
index
31
 -->
	            <div id="main-content" class="
5
index
83
 blq-clearfix">
		

	
<div id="full-width" class="container-full-width">
	<div id="ticker" class="include-only ticker">
    	
882

<div id="tickerHolder"></div>

<noscript> 
	<div class="ticker">
		<h2 class="hidden"> Latest Stories </h2>
				<ul class="tickerItem">		
		 				<li class="tickerEntry">
				<span class="tickerPrompt">BREAKING NEWS</span>
				<span class="tickerHeadline">
    				                        




		


	




<span class="has-icon-boxedlive ">
	<a class="story is-live"  href="http://www.bbc.co.uk/sport/0/olympics/19037273">Rebecca Adlington finishes first in her heat to qualify for the 800m freestyle final<span class="gvl3-icon gvl3-icon-boxedlive"> Live</span></a>

		</span>
  
                      
                    				</span>
			</li> 
						<li class="tickerEntry">
				<span class="tickerPrompt">BREAKING NEWS</span>
				<span class="tickerHeadline">
    				                        




	


	




<span>
	<a class="story"  href="http://www.bbc.co.uk/news/uk-england-manchester-19090706">The ringleader of the Rochdale grooming gang is sentenced to 22 years for 30 counts of rape</a>

		</span>
  
                      
                    				</span>
			</li> 
						<li class="tickerEntry">
				<span class="tickerPrompt">LATEST</span>
				<span class="tickerHeadline">
    				                        




	


	




<span>
	<a class="story"  href="http://www.bbc.co.uk/news/world-europe-19091753">Police detain three suspected al-Qaeda members in southern Spain - media reports</a>

		</span>
  
                      
                    				</span>
			</li> 
						<li class="tickerEntry">
				<span class="tickerPrompt">LATEST</span>
				<span class="tickerHeadline">
    				                        




	


	




<span>
	<a class="story"  href="http://www.bbc.co.uk/news/uk-wales-south-west-wales-19091013">Teenage boy dies after falling off rocks into the sea at the Gower</a>

		</span>
  
                      
                    				</span>
			</li> 
					</ul>
			</div>
</noscript>

<script type="text/javascript">$render("ticker","tickerHolder",{"updatePeriod":30,"dataSource":"http://www.bbc.co.uk/news/10284448/ticker.sjson"});</script>


eac

</div>
<script type="text/javascript">$render("ticker","ticker");</script> 
	
</div>
<script type="text/javascript">$render("container-full-width","full-width");</script> 
	
<div id="now" class="container-now">
	
<div id="container-top-stories-with-splash" class="container-top-stories">
	

		
			
	
	
	<div id="top-story" class="slideshow">
	   			
				
		<h2 class="top-story-header ">
			<a class="story" rel="published-1343877930731" href="/news/uk-19090195">Coaching boost needed, BOA says</a>
		</h2>

	   			  <div id="topStorySlideShow" class="slideshow">
    <img src="http://news.bbcimg.co.uk/media/images/61971000/jpg/_61971719_tv015503682.jpg" width="384" height="216" alt="" />    
</div>

<script type="text/javascript"> 
        $render("slideshow","topStorySlideShow",{ height:216, width:384,
                images : [ 
                                                                                {src:"http://news.bbcimg.co.uk/media/images/61971000/jpg/_61971719_tv015503682.jpg", alt:"Bradley Wiggins stamp"},                                                        {src:"http://news.bbcimg.co.uk/media/images/61971000/jpg/_61971603_015516421.jpg", alt:"A mail box is painted gold in Chorley in honour of Bradley Wiggins&#039; gold medal."},                                                        {src:"http://news.bbcimg.co.uk/media/images/61971000/jpg/_61971601_015515277.jpg", alt:"Team GB&#039;s Michael Jamieson swims breastroke"},                                                        {src:"http://news.bbcimg.co.uk/media/images/61974000/jpg/_61974886_015516437.jpg", alt:"Team GB fencer Sophie Troiano celebrates winning a point"},                                                        {src:"http://news.bbcimg.co.uk/media/images/61974000/jpg/_61974888_015516411.jpg", alt:"Team GB James Austin fights Japan&#039;s Takamasa Anai in judo"}                                        ] 
        }); 
</script> 



	   	
	   	<p>More funding for coaches should be made available to boost home-grown talent, says the British Olympic Association chief. 	 
	   	<span id="dna-comment-count___CPS__19090195" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>

					<ul class="see-also">
				
						
						
			  			  			  			  
			  			  			  			  
			  
			  




		


	




<li class="has-icon-boxedlive first-child column-1">
	<a class="story is-live" rel="published-1343891056846" href="/sport/0/olympics/19037273">Olympics: Day six morning<span class="gvl3-icon gvl3-icon-boxedlive"> Live</span></a>

		</li>

						
			  			  			  
			  			  			  			  
			  
			  




	


	




<li class=" column-1">
	<a class="story" rel="published-1343881756838" href="/news/world-asia-china-19090288">I quit, says China badminton player </a>

		</li>

						
			  			  			  
			  			  			  			  
			  
			  




	


	




<li class=" column-1">
	<a class="story" rel="published-1343887549609" href="/news/uk-england-london-19090898">Wiggins in compulsory helmet call</a>

		</li>

						
			  			  			  
			  			  			  
			  
			  




	


	




<li class=" column-2">
	<a class="story" rel="published-1343863160209" href="/sport/0/olympics/19089596">Wiggins goes from shed to gold</a>

		</li>

						
			  			  			  
			  			  			  
			  
			  




	


	




<li class=" column-2">
	<a class="story" rel="published-1343831991721" href="/news/uk-19083289">Gold medal stamps for GB wins</a>

		</li>

						</ul>
				<hr />
   </div>
   <script  type="text/javascript">$render("top-story","top-story");</script> 

	


    	<div class="container-hyper-topic-cluster">
  	
33a5





		     <div class="hyperpuff">
	       	             
<div class="hyper-container-title">
        


  	<div id="topic-cluster-stories" class="topic-cluster">
	  	  	  
	  <ul class="topic-cluster-stories">
					
												
						
								
				<li class="column-1  first-child">
					




	


	




<h2>
	<a class="story" rel="published-1343862095859" href="/sport/0/olympics/19087264">Day Six must-see moments</a>

	<span id="dna-comment-count___CPS__19087264" class="gvl3-icon gvl3-icon-comment comment-count"></span>					  <a class="from-external-source" href="/sport/0/">BBC Sport</a>
	
	</h2>

				</li>
								
									
						
								
				<li class="column-1 ">
					




	


	




<h2>
	<a class="story" rel="published-1343884939801" href="/sport/0/olympics/19089259">Will technology win track cycling war for GB?</a>

	<span id="dna-comment-count___CPS__19089259" class="gvl3-icon gvl3-icon-comment comment-count"></span>					  <a class="from-external-source" href="/sport/0/">BBC Sport</a>
	
	</h2>

				</li>
								
									
						
								
				<li class="column-1 ">
					




	


	




<h2>
	<a class="story" rel="published-1343841337330" href="http://www.bbc.co.uk/sport/olympics/2012/schedule-results">Full Olympic schedule</a>

	<span id="dna-comment-count___CPS__19085607" class="gvl3-icon gvl3-icon-comment comment-count"></span>				
	</h2>

				</li>
								
									
						
								
				<li class="column-1 ">
					




	


	




<h2>
	<a class="story" rel="published-1343866579207" href="http://www.bbc.co.uk/sport/olympics/2012/medals/countries">Olympics medal table</a>

	<span id="dna-comment-count___CPS__19090123" class="gvl3-icon gvl3-icon-comment comment-count"></span>				
	</h2>

				</li>
								
									
						
												
				<li class="column-2 ">
					




	


	




<h2>
	<a class="story" rel="published-1343885540716" href="/sport/0/olympics/19089818">Lennox Lewis on Team GB boxers</a>

	<span id="dna-comment-count___CPS__19089818" class="gvl3-icon gvl3-icon-comment comment-count"></span>					  <a class="from-external-source" href="/sport/0/">BBC Sport</a>
	
	</h2>

				</li>
								
									
						
												
				<li class="column-2 ">
					




	


	




<h2>
	<a class="story" rel="published-1343818789306" href="/sport/0/olympics/19071987">The golden girls of British rowing</a>

	<span id="dna-comment-count___CPS__19071987" class="gvl3-icon gvl3-icon-comment comment-count"></span>					  <a class="from-external-source" href="/sport/0/">BBC Sport</a>
	
	</h2>

				</li>
								
									
						
												
				<li class="column-2 ">
					




	


	




<h2>
	<a class="story" rel="published-1343664898229" href="/news/uk-19050139">Your Olympic athlete body match</a>

	<span id="dna-comment-count___CPS__19050139" class="gvl3-icon gvl3-icon-comment comment-count"></span>				
	</h2>

				</li>
								
									
						
												
				<li class="column-2 ">
					




	


	




<h2>
	<a class="story" rel="published-1343310379372" href="http://www.bbc.co.uk/2012/">London 2012: Full coverage</a>

	<span id="dna-comment-count___CPS__19001636" class="gvl3-icon gvl3-icon-comment comment-count"></span>				
	</h2>

				</li>
						  </ul>
	</div>
	<script type="text/javascript">$render("topic-cluster","topic-cluster-stories");</script>
  
      
																																								
	<div id="av-promotion" class="av-stories-now">
		
				
				<div class="list-wrapper">
		  
            		  
		  <ul class="av-now-carousel carousel ">
			  				  					  					  					  




		


		




<li class=" first-child">
	<a class="story" rel="published-1343836309787" href="/news/uk-19081335"><img src="http://news.bbcimg.co.uk/media/images/61961000/jpg/_61961783_boris.jpg" alt="The Mayor of London Boris Johnson" />Boris Johnson left hanging on zip wire  <span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">00:26</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343842153005" href="/sport/0/olympics/19086712"><img src="http://news.bbcimg.co.uk/media/images/61964000/jpg/_61964670_61963760.jpg" alt="Bradley Wiggins" />Career will never get better - Wiggins<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">02:52</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343859968322" href="/news/magazine-19084494"><img src="http://news.bbcimg.co.uk/media/images/61969000/jpg/_61969267_61959677.jpg" alt="Female boxers" />Women face off in the Olympic ring<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">03:32</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343821950525" href="/sport/0/olympics/19079975"><img src="http://news.bbcimg.co.uk/media/images/61953000/jpg/_61953306_glover.jpg" alt="Helen Glover and Heather Stanning" />First Team GB gold medal for rowing pair<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">02:09</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343843390704" href="/news/uk-19086651"><img src="http://news.bbcimg.co.uk/media/images/61965000/jpg/_61965083_jex_1482716_de01-1.jpg" alt="a fake Olympics ticket" />Ticket touts: &#039;Dark side of 2012&#039;<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">03:02</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343849292936" href="/sport/0/olympics/19088184"><img src="http://news.bbcimg.co.uk/media/images/61967000/jpg/_61967555_jamieson.jpg" alt="Michael Jamieson" />Swimming silver for GB&#039;s Jamieson<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:30</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343858820287" href="/news/uk-19089117"><img src="http://news.bbcimg.co.uk/media/images/61969000/jpg/_61969699_jex_1482805_de27-1.jpg" alt="Bradley Wiggins discussing Sean Yates with Gary Lineker" />Voice in ear keeps Wiggins on target<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:45</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343861896372" href="/news/19088171"><img src="http://news.bbcimg.co.uk/media/images/61970000/jpg/_61970302_61970292.jpg" alt="Michael Phelps" />Pool where it all began for Phelps<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">02:20</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343853952310" href="/news/uk-19088743"><img src="http://news.bbcimg.co.uk/media/images/61968000/jpg/_61968633_61968624.jpg" alt="Heather Stanning and Helen Glover" />Gold medallists get giant postage stamp<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:00</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343851563410" href="/sport/0/olympics/19083919"><img src="http://news.bbcimg.co.uk/media/images/61968000/jpg/_61968274_jex_1482766_de27-1.jpg" alt="Michael Jamieson smiling after winning silver medal" />Jamieson &#039;delighted with silver&#039;<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:42</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343844718033" href="/news/uk-19081337"><img src="http://news.bbcimg.co.uk/media/images/61964000/jpg/_61964693_boat.jpg" alt="Heather Stanning and Helen Glover" />Going from a rowing boat to a river barge<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:18</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343810905602" href="/news/uk-19076244"><img src="http://news.bbcimg.co.uk/media/images/61946000/jpg/_61946036_jex_1482051_de01-1.jpg" alt="Badminton at London 2012 Olympics" />&#039;Most embarrassing badminton match&#039;<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">02:00</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343831057443" href="/news/uk-19081334"><img src="http://news.bbcimg.co.uk/media/images/61958000/jpg/_61958415_badminton.jpg" alt="The Chief Operating Officer of the Badminton World Federation, Thomas Lund." />Eight badminton players disqualified<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:39</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343810395956" href="/news/uk-19074912"><img src="http://news.bbcimg.co.uk/media/images/61951000/jpg/_61951118_shoes.jpg" alt="The Duchess of Cambridge&#039;s shoes" />Adlington admires the Duchess&#039;s shoes<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:12</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343819658841" href="/news/uk-19074913"><img src="http://news.bbcimg.co.uk/media/images/61951000/jpg/_61951031_61946273.jpg" alt="Sebastian Coe" />Coe: &#039;Badminton was very depressing&#039;<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">00:42</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343779812702" href="/sport/0/olympics/19073935"><img src="http://news.bbcimg.co.uk/media/images/61945000/jpg/_61945324_badminton.jpg" alt="Badminton players confronted by referee" />Fans jeer badminton players for &#039;not trying&#039;<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:58</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343847767801" href="/news/uk-19086648"><img src="http://news.bbcimg.co.uk/media/images/61964000/jpg/_61964676_jex_1482681_de26-1.jpg" alt="David Walliams" />Walliams &#039;blessed&#039; Olympics in London<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">02:21</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343775448741" href="/sport/0/olympics/19072220"><img src="http://news.bbcimg.co.uk/media/images/61942000/png/_61942056_mmolyswimleclosdad.png" alt="Chad le Clos&#039;s father Bert" />Overcome by son&#039;s victory over Phelps<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:46</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343750842277" href="/sport/0/olympics/19069378"><img src="http://news.bbcimg.co.uk/media/images/61934000/jpg/_61934801_mmolyequzaraphillipsmedalceremony.jpg" alt="Zara Phillips embraces her mother after winning silver" />&#039;Thanks Mum!&#039; Zara gets Olympic silver<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:36</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343430713566" href="/news/uk-19022259"><img src="http://news.bbcimg.co.uk/media/images/61866000/jpg/_61866116_stadium.jpg" alt="Fireworks at the Olympic stadium" />Opening ceremony highlights<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">06:32</span></a>

		</li>

				  			  		  </ul>
		</div>
		
	</div>

	<script type="text/javascript">$render("av-stories-now","av-promotion");</script>


  </div>

	       	     </div>
	
60f1

  	</div>
  
	
	
		
			
	
      
	<div id="second-story" class="secondary-top-story">
	
      	      <h2 class="secondary-top-story-heading">Other Top Stories</h2>
	            	    
      <div class="large-image">
          	    




	


		




<h3 class=" secondary-story-header">
	<a class="story" rel="published-1343863125509" href="/news/business-19088300"><img src="http://news.bbcimg.co.uk/media/images/61968000/jpg/_61968987_61967322.jpg" alt="Mario Draghi" />ECB poised for crucial meeting</a>

		</h3>

																
	    <p>The European Central Bank will hold its latest meeting amid much speculation that it will take unprecedented steps to help shore up the euro. 	
	    <span id="dna-comment-count___CPS__19088300" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>

					<ul class="see-also">
				
						
						
			  			  			  			  
			  			  			  			  
			  
			  




	


	




<li class=" first-child column-1">
	<a class="story" rel="published-1343902262515" href="/news/business-19093508">Have politics of the ECB changed?</a>

					
	</li>

						
			  			  			  
			  			  			  			  
			  
			  




	


	




<li class=" column-1">
	<a class="story" rel="published-1343652116085" href="/news/business-19044341">Will the ECB&#039;s bond plan work?</a>

					
	</li>

						
			  			  			  
			  			  			  
			  
			  




	


	




<li class=" column-2">
	<a class="story" rel="published-1343812476498" href="/news/business-19077140">Peston: Limits to ECB&#039;s actions</a>

					
	</li>

						
			  			  			  
			  			  			  
			  
			  




	


	




<li class=" column-2">
	<a class="story" rel="published-1343846781757" href="/news/business-19087742">US Fed signals stimulus action</a>

					
	</li>

						</ul>
			   </div>
	</div>
<script type="text/javascript">$render("secondary-top-story","second-story");</script> 


	
	
		
			
	
      
	<div id="third-story" class="secondary-top-story">
	
      	    
      <div class="medium-image">
          	    




	


		




<h2 class=" secondary-story-header">
	<a class="story" rel="published-1343902564701" href="/news/uk-england-manchester-19090706"><img src="http://news.bbcimg.co.uk/media/images/61977000/jpg/_61977254_shabir_ahmed_gmp.jpg" alt="Shabir Ahmed" />Sex gang man jailed for 22 years</a>

		</h2>

																
	    <p>A man jailed for leading the Rochdale sex grooming gang is jailed concurrently for a further 22 years for 30 child rape offences. 	
	    <span id="dna-comment-count___CPS__19090706" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>

					<ul class="see-also">
				
						
						
			  			  			  			  
			  			  			  			  
			  
			  




	


	




<li class=" first-child column-1">
	<a class="story" rel="published-1340291650834" href="/news/uk-england-manchester-18540902">Sex gang man raped girl for years</a>

					
	</li>

						
			  			  			  
			  			  			  
			  
			  




	


	




<li class=" column-2">
	<a class="story" rel="published-1336546032631" href="/news/uk-england-17993003">Child sex ring members all jailed</a>

					
	</li>

						</ul>
			   </div>
	</div>
<script type="text/javascript">$render("secondary-top-story","third-story");</script> 


	




												
				
																							
																					
																					
																					
																					
																					
																					
																					
									
			
			

												
				
																					
				
																							
																					
																					
																					
																					
																					
																					
									
		
			
							
			
							
		
<div id="other-top-stories" class="other-top-stories">
			
	<ul class="other-top-stories-stories">

				  	
												
							
																				
				<li class="column-1 with-summary  first-child">

                              					




	


	




<h2>
	<a class="story" rel="published-1343862005182" href="/news/uk-19083936">Call for prison remand overhaul</a>

		</h2>

																	
											<p>The way prisoners on remand are held should be changed to improve fairness and reduce costs, the chief inspector of prisons says. 	
						<span id="dna-comment-count___CPS__19083936" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>
									</li>
							  	
									
							
																				
				<li class="column-1 with-summary ">

                              					




	


	




<h2>
	<a class="story" rel="published-1343881226459" href="/news/world-middle-east-19090143">&#039;Dozens die&#039; in Damascus raids</a>

		</h2>

																	
											<p>Syrian forces killed at least 70 people in two attacks in Damascus, activists say, as rebels attack an air base in the north. 	
						<span id="dna-comment-count___CPS__19090143" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>
									</li>
							  	
									
							
																
				<li class="column-2 ">

                    					




	


	




<h2>
	<a class="story" rel="published-1343899435532" href="/news/world-europe-19091753">&#039;Al-Qaeda&#039; trio arrested in Spain</a>

	<span id="dna-comment-count___CPS__19091753" class="gvl3-icon gvl3-icon-comment comment-count"></span>				
	</h2>

																	
									</li>
							  	
									
							
																
				<li class="column-2 ">

                    					




	


	




<h2>
	<a class="story" rel="published-1343812044471" href="/news/science-environment-19076355">Higgs results &#039;get even stronger&#039;</a>

	<span id="dna-comment-count___CPS__19076355" class="gvl3-icon gvl3-icon-comment comment-count"></span>				
	</h2>

																	
									</li>
							  	
									
							
																
				<li class="column-2 ">

                    					




	


	




<h2>
	<a class="story" rel="published-1343867908823" href="/news/uk-19089945">Putin on first UK trip since 2005</a>

	<span id="dna-comment-count___CPS__19089945" class="gvl3-icon gvl3-icon-comment comment-count"></span>				
	</h2>

																	
									</li>
							  	
									
							
																
				<li class="column-2 ">

                    					




	


	




<h2>
	<a class="story" rel="published-1343862447203" href="/news/entertainment-arts-19084838">Record for BBC digital stations</a>

	<span id="dna-comment-count___CPS__19084838" class="gvl3-icon gvl3-icon-comment comment-count"></span>				
	</h2>

																	
									</li>
							  	
									
							
																
				<li class="column-2 ">

                    					




	


	




<h2>
	<a class="story" rel="published-1343879768269" href="/news/world-asia-india-19090467">India allows Pakistan investment</a>

	<span id="dna-comment-count___CPS__19090467" class="gvl3-icon gvl3-icon-comment comment-count"></span>				
	</h2>

																	
									</li>
							  	
									
							
																
				<li class="column-2 ">

                    					




	


	




<h2>
	<a class="story" rel="published-1343897937413" href="/news/uk-wales-south-west-wales-19091013">Teenager dies after coast rescue</a>

	<span id="dna-comment-count___CPS__19091013" class="gvl3-icon gvl3-icon-comment comment-count"></span>				
	</h2>

																	
									</li>
							  	
									
							
																
				<li class="column-2 ">

                    					




	


	




<h2>
	<a class="story" rel="published-1343860795302" href="/news/world-us-canada-19088881">Chen seeks US pressure on China</a>

	<span id="dna-comment-count___CPS__19088881" class="gvl3-icon gvl3-icon-comment comment-count"></span>				
	</h2>

																	
									</li>
						</ul>
</div>
<script type="text/javascript">$render("other-top-stories","other-top-stories");</script>

</div>
<script type="text/javascript">$render("container-top-stories","container-top-stories-with-splash");</script> 
	
			
	<div id="also-in-the-news" class="also-in-news">
				 	<h2 class="also-in-news-header"><a href="/news/also_in_the_news/">Also in the News</a></h2>
			
		<ul>
					
										
					
									
			
							<li class="small-image column-1 first-child">

					




	


		




<h3>
	<a class="story" rel="published-1343841976921" href="/news/entertainment-arts-19078948"><img src="http://news.bbcimg.co.uk/media/images/61956000/jpg/_61956162_61949683.jpg" alt="Vertigo still" />Vertigo is named &#039;greatest film&#039;</a>

					
	</h3>

				</li>
						
			
					
										
					
						
			
							<li class="small-image column-2 ">

					




	


		




<h3>
	<a class="story" rel="published-1343851489105" href="/news/science-environment-19077439"><img src="http://news.bbcimg.co.uk/media/images/61965000/jpg/_61965968_61965927.jpg" alt="Palm trees" />Palm trees &#039;grew in Antarctica&#039;</a>

					
	</h3>

				</li>
						
			
				</ul>
		
	</div>
	<script type="text/javascript">$render("also-in-news","also-in-the-news");</script>

	
<div id="compact-more-from-bbc-news" class="container-digest-grid">
    
          <div class="digest-wrapper digest-grid">
                                        
      
  
  
  <div class="digest-unit first-child">

         	<h2 class="heading-16"><a href="/news/business/">Business</a></h2>
    
          <ul>
      
        
                    
                            
          




	


		




<li class=" first-child stacked-144">
	<a class="headline-anchor" rel="published-1343888609255" href="/news/business-19090792"><img src="http://news.bbcimg.co.uk/media/images/61971000/jpg/_61971678_012442815-1.jpg" alt="Sky logo outside of its office in west London" /><span class="headline heading-13">Sky cleared over pay-TV movies</span></a>
				<br class="ie-clear" />
</li>

        
                    
                            
          




	


	




<li class=" list-headline">
	<a class="headline-anchor" rel="published-1343900988744" href="/news/business-19093628"><span class="headline heading-13">Construction sector &#039;recovering&#039;</span></a>
				<br class="ie-clear" />
</li>

              </ul>
      </div>

  


                                    
    
  
  
  <div class="digest-unit ">

         	<h2 class="heading-16"><a href="/news/politics/">Politics</a></h2>
    
          <ul>
      
        
                    
                            
          




	


		




<li class=" first-child stacked-144">
	<a class="headline-anchor" rel="published-1343895974277" href="/news/uk-politics-19060650"><img src="http://news.bbcimg.co.uk/media/images/61935000/jpg/_61935600_61923789.jpg" alt="Nigel Farage" /><span class="headline heading-13">Farage: UK elections don&#039;t matter</span></a>
				<br class="ie-clear" />
</li>

        
                    
                            
          




	


	




<li class=" list-headline">
	<a class="headline-anchor" rel="published-1343854899066" href="/news/business-19086052"><span class="headline heading-13">No-frills savings plans outlined</span></a>
				<br class="ie-clear" />
</li>

              </ul>
      </div>

  


                                    
    
  
  
  <div class="digest-unit ">

         	<h2 class="heading-16"><a href="/news/health/">Health</a></h2>
    
          <ul>
      
        
                    
                            
          




	


		




<li class=" first-child stacked-144">
	<a class="headline-anchor" rel="published-1343840406710" href="/news/health-19083685"><img src="http://news.bbcimg.co.uk/media/images/61959000/jpg/_61959819_61959811.jpg" alt="Cancer stem cells" /><span class="headline heading-13">Stem cells drive tumour growth</span></a>
				<br class="ie-clear" />
</li>

        
                    
                            
          




	


	




<li class=" list-headline">
	<a class="headline-anchor" rel="published-1343872634610" href="/news/health-19076398"><span class="headline heading-13">Brain training best value for ME</span></a>
				<br class="ie-clear" />
</li>

              </ul>
      </div>

  


                                    
    
  
  
  <div class="digest-unit ">

         	<h2 class="heading-16"><a href="/news/education/">Education</a></h2>
    
          <ul>
      
        
                    
                            
          




	


		




<li class=" first-child stacked-144">
	<a class="headline-anchor" rel="published-1343837451511" href="/news/uk-wales-politics-19078094"><img src="http://news.bbcimg.co.uk/media/images/61963000/jpg/_61963062_andrews512.jpg" alt="Leighton Andrews AM" /><span class="headline heading-13">Ministers write to Gove on GCSEs</span></a>
				<br class="ie-clear" />
</li>

        
                    
                            
          




	


	




<li class=" list-headline">
	<a class="headline-anchor" rel="published-1343873387994" href="/news/education-19076860"><span class="headline heading-13">Bodleian appeal for Bard online</span></a>
				<br class="ie-clear" />
</li>

              </ul>
      </div>

  


                                                      </div>
          <div class="digest-wrapper digest-grid">
                                                                                
      
  
  
  <div class="digest-unit first-child">

         	<h2 class="heading-16"><a href="/news/technology/">Technology</a></h2>
    
          <ul>
      
        
                    
                            
          




	


		




<li class=" first-child stacked-144">
	<a class="headline-anchor" rel="published-1343863041164" href="/news/technology-19085980"><img src="http://news.bbcimg.co.uk/media/images/61963000/jpg/_61963899_photo2.jpg" alt="A 3D version of an animated figure, printed on a 3D printer" /><span class="headline heading-13">3D printing video game characters</span></a>
				<br class="ie-clear" />
</li>

        
                    
                            
          




	


	




<li class=" list-headline">
	<a class="headline-anchor" rel="published-1343871885222" href="/news/business-19090173"><span class="headline heading-13">Samsung lawyer defends press note</span></a>
				<br class="ie-clear" />
</li>

              </ul>
      </div>

  


                                    
    
  
  
  <div class="digest-unit ">

         	<h2 class="heading-16"><a href="/news/science_and_environment/">Sci/Environment</a></h2>
    
          <ul>
      
        
                    
                            
          




	


		




<li class=" first-child stacked-144">
	<a class="headline-anchor" rel="published-1343900790864" href="/nature/19072196"><img src="http://news.bbcimg.co.uk/media/images/61974000/jpg/_61974515_grass_spider_on_long_island_maine_aug_2008.jpg" alt="Grass spider" /><span class="headline heading-13">Cannibal spiders lay better eggs</span></a>
				<br class="ie-clear" />
</li>

        
                    
                            
          




	


	




<li class=" list-headline">
	<a class="headline-anchor" rel="published-1343832331765" href="/news/science-environment-19050796"><span class="headline heading-13">Mangrove CO2 storage &#039;economic&#039; </span></a>
				<br class="ie-clear" />
</li>

              </ul>
      </div>

  


                                    
    
  
  
  <div class="digest-unit ">

         	<h2 class="heading-16"><a href="/news/entertainment_and_arts/">Entertainment</a></h2>
    
          <ul>
      
        
                    
                            
          




	


		




<li class=" first-child stacked-144">
	<a class="headline-anchor" rel="published-1343897948309" href="/news/entertainment-arts-19091521"><img src="http://news.bbcimg.co.uk/media/images/61973000/jpg/_61973714_015513747-1.jpg" alt="Jermaine Jackson" /><span class="headline heading-13">Jermaine regrets Jackson feud</span></a>
				<br class="ie-clear" />
</li>

        
                    
                            
          




	


	




<li class=" list-headline">
	<a class="headline-anchor" rel="published-1343902360312" href="/news/entertainment-arts-19093415"><span class="headline heading-13">Cocker seeks Pussy Riot release</span></a>
				<br class="ie-clear" />
</li>

              </ul>
      </div>

  


                                    
    
  
  
  <div class="digest-unit ">

         	<h2 class="heading-16"><a href="/news/magazine/">Magazine</a></h2>
    
          <ul>
      
        
                    
                            
          




	


		




<li class=" first-child stacked-144">
	<a class="headline-anchor" rel="published-1343870860657" href="/news/magazine-19077733"><img src="http://news.bbcimg.co.uk/media/images/61951000/jpg/_61951860_mer_wgm_1163_large.jpg" alt="Armed steam ship &#039;Nemesis&#039;" /><span class="headline heading-13">Viewpoint: G4S and the echoes of the East India Company</span></a>
				<br class="ie-clear" />
</li>

        
                    
                            
          




	


	




<li class=" list-headline">
	<a class="headline-anchor" rel="published-1343777469017" href="/news/magazine-19050342"><span class="headline heading-13">Whatever happened to kids&#039; chemistry sets?</span></a>
				<br class="ie-clear" />
</li>

              </ul>
      </div>

  


              </div>
  </div>
<script type="text/javascript">$render("container-compact-section-digests","compact-more-from-bbc-news");</script>


	
<div id="featured-other-site---bbc-sport" class="container-featured-other-site">
	
<div id="featured-site-top-stories---bbc-sport" class="featured-site-top-stories">

		 	<h2><a href="http://www.bbc.co.uk/sport/">Sport</a></h2>
	
	<ul>
			
													
					
						
		<li class=" medium-image first-child">

			




		


		




<h3>
	<a class="story is-live" rel="published-1343899243012" href="/sport/0/cricket/19045274"><img src="http://news.bbcimg.co.uk/media/images/61976000/jpg/_61976860_finn_swann_getty.jpg" alt="Steven Finn and Graeme Swann" />England v South Africa<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-live"> Live</span></span></a>

		</h3>

			
						  <p>England win the toss and field against South Africa in the second Test at Headingley, with Steven Finn replacing Graeme Swann.</p>
						
			
			
						
						  <hr />
					</li>
	
			
				
							
									
										
		<li class="column-1 ">

			




	


	




<h3>
	<a class="story" rel="published-1343884586548" href="/sport/0/football/19086404">Arsenal hopeful of double signing</a>

		</h3>

			
						
			
			
						
					</li>
	
			
				
							
									
										
		<li class="column-2 ">

			




	


	




<h3>
	<a class="story" rel="published-1343875739964" href="/news/business-19090179">Inter Milan in Chinese stake sale</a>

		</h3>

			
						
			
			
						
					</li>
	
		</ul>
</div>
<script type="text/javascript">$render("featured-site-top-stories","featured-site-top-stories---bbc-sport");</script> 

</div>
<script type="text/javascript">$render("container-featured-other-site","featured-other-site---bbc-sport");</script> 
	<div id="geographic-news-digests-no-tabs" class="container-digest-grid">
	

<div id="expanded-geographic-news-digests" class=" container-block-grid">
	<h2 class="heading-24">UK &amp; Local News</h2>
	
  
                    
    <div class="digest-wrapper digest-grid">
                              
	
    
  <div class="digest-unit first-child">
         	<h3 class="heading-16">
     	     	  <a href="/news/england/">England</a>
           	
                 	</h3>
        
    <ul>
    
                        
              




	


		




<li class=" stacked-144 first-child">
	<a class="headline-anchor" rel="published-1343887549609" href="/news/uk-england-london-19090898"><img src="http://news.bbcimg.co.uk/media/images/61973000/jpg/_61973604_cyclistaccidentgetty464.jpg" alt="Accident scene" /><span class="headline heading-13">Wiggins in compulsory helmet call</span></a>
				<br class="ie-clear" />
</li>

																					  
		
            
    
                        
              




	


	




<li>
	<a class="headline-anchor" rel="published-1343894758502" href="/news/uk-england-devon-19090663">Dinghy rower, 10, rescues couple</a>
				<br class="ie-clear" />
</li>

            
        </ul>
	  
  </div>



                          
	
  
  <div class="digest-unit ">
         	<h3 class="heading-16">
     	     	  <a href="/news/scotland/">Scotland</a>
           	
                 	</h3>
        
    <ul>
    
                        
              




	


		




<li class=" stacked-144 first-child">
	<a class="headline-anchor" rel="published-1343899695904" href="/news/uk-scotland-19093528"><img src="http://news.bbcimg.co.uk/media/images/61975000/jpg/_61975145_001901127-1.jpg" alt="Shoppers" /><span class="headline heading-13">Scots population hits record high</span></a>
				<br class="ie-clear" />
</li>

																					  
		
            
    
                        
              




	


	




<li>
	<a class="headline-anchor" rel="published-1343900272423" href="/news/uk-scotland-glasgow-west-19093292">Safety call over fatal road crash</a>
				<br class="ie-clear" />
</li>

            
        </ul>
	  
  </div>



                          
	
  
  <div class="digest-unit ">
         	<h3 class="heading-16">
     	     	  <a href="/news/northern_ireland/">Northern Ireland</a>
           	
                 	</h3>
        
    <ul>
    
                        
              




	


		




<li class=" stacked-144 first-child">
	<a class="headline-anchor" rel="published-1343888865075" href="/news/uk-northern-ireland-19091135"><img src="http://news.bbcimg.co.uk/media/images/61971000/jpg/_61971759_chambersnew.jpg" alt="Peter Chambers (centre) and his brother Richard (left) after last year&#039;s World Cup win in Lucerne" /><span class="headline heading-13">Chambers brothers going for gold</span></a>
				<br class="ie-clear" />
</li>

																					  
		
            
    
                        
              




	


	




<li>
	<a class="headline-anchor" rel="published-1343892777980" href="/news/uk-northern-ireland-19091270">Quinn will not return to Republic</a>
				<br class="ie-clear" />
</li>

            
        </ul>
	  
  </div>



                          
	
  
  <div class="digest-unit ">
         	<h3 class="heading-16">
     	     	  <a href="/news/wales/">Wales</a>
           	
                 	</h3>
        
    <ul>
    
                        
              




	


		




<li class=" stacked-144 first-child">
	<a class="headline-anchor" rel="published-1343886753251" href="/news/uk-wales-19086903"><img src="http://news.bbcimg.co.uk/media/images/61968000/jpg/_61968847_lorry4641.jpg" alt="Photo of lorry" /><span class="headline heading-13">Business call after A55 shutdown</span></a>
				<br class="ie-clear" />
</li>

																					  
		
            
    
                        
              




	


	




<li>
	<a class="headline-anchor" rel="published-1343888595495" href="/news/uk-wales-south-west-wales-19085391">Poor turnout hits e-book festival</a>
				<br class="ie-clear" />
</li>

            
        </ul>
	  
  </div>



              </div>
      <div class="digest-wrapper digest-grid">
                                                      

			
b5
<div id="geo-uk-digest" class="geo-digest-region-2">
<script type="text/javascript">$render("personalisation-panel","geo-uk-digest",{panelId:"personalisation"});</script>
</div>

1aab

		
				
        </div>
  </div>

	
<div id="compact-geographic-section-digests" class="container-block-grid">
     	<h2 class="heading-24"><a href="/news/world/">World News</a></h2>
  
      
        <div class="digest-wrapper digest-grid-list-column">
                                  
  <div class="digest-unit first-child">
         	<h3 class="heading-16"><a href="/news/world/africa/">Africa</a></h3>
    
	  




	


	




<div class=" standard-no-image">
	<a class="headline-anchor" rel="published-1343831861291" href="/news/world-middle-east-19075291">New Egypt cabinet to be announced</a>
	<span id="dna-comment-count___CPS__19075291" class="gvl3-icon gvl3-icon-comment comment-count"></span>			<br class="ie-clear" />
</div>

  </div>

                            
  <div class="digest-unit ">
         	<h3 class="heading-16"><a href="/news/world/asia/">Asia</a></h3>
    
	  




	


	




<div class=" standard-no-image">
	<a class="headline-anchor" rel="published-1343881756838" href="/news/world-asia-china-19090288">China badminton player &#039;to quit&#039;</a>
	<span id="dna-comment-count___CPS__19090288" class="gvl3-icon gvl3-icon-comment comment-count"></span>			<br class="ie-clear" />
</div>

  </div>

                            
  <div class="digest-unit ">
         	<h3 class="heading-16"><a href="/news/world/europe/">Europe</a></h3>
    
	  




	


	




<div class=" standard-no-image">
	<a class="headline-anchor" rel="published-1343856310196" href="/news/world-europe-19085236">Greece agrees new bailout cuts</a>
	<span id="dna-comment-count___CPS__19085236" class="gvl3-icon gvl3-icon-comment comment-count"></span>			<br class="ie-clear" />
</div>

  </div>

                          </div>
        <div class="digest-wrapper digest-grid-list-column">
                                                    
  <div class="digest-unit first-child">
         	<h3 class="heading-16"><a href="/news/world/latin_america/">Latin America</a></h3>
    
	  




	


	




<div class=" standard-no-image">
	<a class="headline-anchor" rel="published-1343897726547" href="/news/world-latin-america-19091137">Brazil set for big bribery trial</a>
	<span id="dna-comment-count___CPS__19091137" class="gvl3-icon gvl3-icon-comment comment-count"></span>			<br class="ie-clear" />
</div>

  </div>

                            
  <div class="digest-unit ">
         	<h3 class="heading-16"><a href="/news/world/middle_east/">Middle East</a></h3>
    
	  




	


	




<div class=" standard-no-image">
	<a class="headline-anchor" rel="published-1343899059304" href="/news/world-middle-east-19091147">Hamas condemns Auschwitz visit</a>
	<span id="dna-comment-count___CPS__19091147" class="gvl3-icon gvl3-icon-comment comment-count"></span>			<br class="ie-clear" />
</div>

  </div>

                            
  <div class="digest-unit ">
         	<h3 class="heading-16"><a href="/news/world/us_and_canada/">US &amp; Canada</a></h3>
    
	  




	


	




<div class=" standard-no-image">
	<a class="headline-anchor" rel="published-1343872633816" href="/news/world-us-canada-19089970">Third Californian city bankruptcy</a>
	<span id="dna-comment-count___CPS__19089970" class="gvl3-icon gvl3-icon-comment comment-count"></span>			<br class="ie-clear" />
</div>

  </div>

        </div>
  </div>



</div>
<script type="text/javascript">$render("container-digest-grid","geographic-news-digests-no-tabs");</script> 

	
																
	<div id="picture-galleries" class="av-stories-now">
		
				 	<h2 class="av-now-header"><a href="/news/in_pictures/">In Pictures</a></h2>
				
				<div class="list-wrapper">
		  
            		  
		  <ul class="av-now-carousel carousel ">
			  				  					  					  					  




	


		




<li class=" first-child">
	<a class="story" rel="published-1343817994677" href="/sport/0/olympics/19077684"><img src="http://news.bbcimg.co.uk/media/images/61971000/jpg/_61971636_wiggins_promo.jpg" alt="Wiggins" />Olympic day five</a>

		</li>

				  			  				  					  					  




	


		




<li>
	<a class="story" rel="published-1343818895870" href="/news/in-pictures-19076154"><img src="http://news.bbcimg.co.uk/media/images/61969000/jpg/_61969436_61946292.jpg" alt="Multiple bolts of lightning streak " />Day in pictures</a>

		</li>

				  			  				  					  					  




	


		




<li>
	<a class="story" rel="published-1343734117867" href="/sport/0/olympics/19062174"><img src="http://news.bbcimg.co.uk/media/images/61927000/jpg/_61927215_zige_liu_butterfly_getty.jpg" alt="Zige Liu" />2012 Olympics</a>

		</li>

				  			  				  					  					  




	


		




<li>
	<a class="story" rel="published-1343636043437" href="/news/world-asia-india-19044827"><img src="http://news.bbcimg.co.uk/media/images/61938000/jpg/_61938372_officer_rtr.jpg" alt="Officer reads documents in Chandigarh, India (31 July 2012)" />Power crisis </a>

		</li>

				  			  				  					  					  




	


		




<li>
	<a class="story" rel="published-1343637971711" href="/news/world-latin-america-19044459"><img src="http://news.bbcimg.co.uk/media/images/61896000/jpg/_61896879_kimblerley_rtr.jpg" alt="Carnival queen Kimberley Benoit, 22, blows a kiss to the crowd" />Carnival of flowers</a>

		</li>

				  			  				  					  					  




	


		




<li>
	<a class="story" rel="published-1343733987830" href="/news/in-pictures-19060388"><img src="http://news.bbcimg.co.uk/media/images/61921000/jpg/_61921927_61921200.jpg" alt="Carnival of flowers in Port-au-Prince, Haiti" />Day in pictures</a>

		</li>

				  			  				  					  					  




	


		




<li>
	<a class="story" rel="published-1343549838811" href="/news/world-middle-east-19035078"><img src="http://news.bbcimg.co.uk/media/images/61880000/jpg/_61880121_j66zpznd.jpg" alt="Rebels in Aleppo break their Ramadan fast with an &quot;iftar&quot; meal (24 July)" />Battle for Aleppo</a>

		</li>

				  			  				  					  					  




	


		




<li>
	<a class="story" rel="published-1343648902725" href="/news/in-pictures-19045101"><img src="http://news.bbcimg.co.uk/media/images/61899000/jpg/_61899928_hi015455422.jpg" alt="A protester is taken into custody by Orange County Police Officers" />Day in pictures</a>

		</li>

				  			  		  </ul>
		</div>
		
	</div>

	<script type="text/javascript">$render("av-stories-now","picture-galleries");</script>


	
<div id="featured-other-site---democracy-live" class="container-featured-other-site">
	<div id="featured-site-include-2---democracy-live" class="include-only featured-site-include">
    	
3e
<div id="find-a-representative" class="find-a-representative">
46e
  <div class="content-object-34">
        
        <h2>Find a representative</h2>
                                            
        <div class="content-container">
          
          <form id="content-object-34-form" method="get" action="/democracylive/hi/representatives/search" accept-charset="UTF-8">
                                 
            <fieldset class="content-object-34-fieldset">
                                  
                <legend><span>Search terms</span></legend>
                                  
                  <label for="content-object-34-form-keyword">Find your political representatives, enter their name, your full postcode e.g. CF10 3NQ or place name</label>
                  <input id="content-object-34-form-keyword" name="q" type="text" class="input"/>
                                                               
                  <input type="submit" value="Search" class="submit" id="content-object-34-form-submit"/>
        
              </fieldset>    
                                                                 
        </form>

        </div>
                
    </div>
fb
</div>
<script type="text/javascript">
$render("hide-text-input-labels","find-a-representative");
gloader.load(["glow","1","glow.forms"],{onLoad: function(glow){new glow.forms.Form("#content-object-34-form").addTests("q", ["required"]);}});
</script> 
11a

</div>
<script type="text/javascript">$render("featured-site-include-2---democracy-live","featured-site-include-2---democracy-live");</script> 
</div>
<script type="text/javascript">$render("container-featured-other-site","featured-other-site---democracy-live");</script> 
	

6f8
<div class="languages">
  <h3><a href="http://www.bbc.co.uk/worldservice/">BBC World Service</a></h3>
  <h4>News and analysis in 27 languages</h4>
  <ul>
	<li><a href="http://www.bbc.co.uk/arabic"><span class="lang-with-image">Arabic</span> <span class="lang-sprite lang-arabic">????</span></a></li>
	<li><a href="http://www.bbc.co.uk/chinese"><span class="lang-with-image">Chinese</span> <span class="lang-sprite lang-chinese">&#20013;&#25991;</span></a></li>
  </ul>
  <h5>Languages continued (2 of 4)</h5>
  <ul>
	<li><a href="http://www.bbcpersian.com/"><span class="lang-with-image">Persian</span> <span class="lang-sprite lang-persian">&#x0641;&#x0627;&#x0631;&#x0633;&#x06cc;</span></a></li>
	<li><a href="http://www.bbc.co.uk/portuguese"><span class="lang-with-image">Portuguese</span> <span class="lang-sprite lang-brasil">Brasil</span></a></li>
  </ul>
  <h5>Languages continued (3 of 4)</h5>
  <ul>
	<li><a href="http://www.bbc.co.uk/russian"><span class="lang-with-image">Russian</span> <span class="lang-sprite lang-russian">&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;</span></a></li>
	<li><a href="http://www.bbcmundo.com/"><span class="lang-with-image">Spanish</span> <span class="lang-sprite lang-mundo">Mundo</span></a></li>
  </ul>
  <h5>Languages continued (4 of 4)</h5>
  <ul>
	<li><a href="http://www.bbcurdu.com/"><span class="lang-with-image">Urdu</span> <span class="lang-sprite lang-urdu">&#x0627;&#x0631;&#x062f;&#x0648;</span></a></li>
	<li><a href="http://www.bbc.co.uk/vietnamese"><span class="lang-with-image">Vietnamese</span> <span class="lang-sprite lang-vietnamese">Ti&#x1ebf;ng Vi&#x1ec7;t</span></a></li>
  </ul>
  <div class="languages-footer">
		<a href="http://www.bbc.co.uk/worldservice/languages/">More languages</a>
  </div>
</div>

ea


</div>
<script type="text/javascript">$render("container-now","now");</script> 
	
<div id="best" class="container-best">
	<div id="special-event-promotion-best-include" class="include-only special-event-promotion-best">
    	
3630
<!-- Olympics Today at the Games -->
<style type="text/css">

.today-at-the-games h2.heading-plain {
    color: #505050;
    font-size: 1.846em;
    letter-spacing: -1px;
    line-height: 24px;
    margin: 0;
    padding: 7px 8px 9px;
    position: relative;
}

.mod .heading-small {
    font-size: 1.23077em;
}

.gelui-carousel .gelui-carousel-button:hover{
	opacity:1;
} 

.gelui-carousel .gelui-carousel-button-disabled{
	display:none;
}

.schedule p{
	padding:2px 0 2px 56px;
}

.schedule .event-days,
.schedule .days-to-go{
	font-weight:bold;
	line-height:1;
}

.schedule .event-days{
	color:#1659b4;
	font-size:2.69em;
	margin-right:-4px;
}

.schedule .days-to-go{
	color:#d1700e;
	font-size:2.08em;
}

.schedule-carousel .carousel{
	width:3000px;
}
.schedule-carousel .gelui-carousel-navigation{
	height:74px;
	width:14px;
	border-top:1px solid #fff;
	border-bottom:1px solid #fff;
}

.schedule-carousel .gelui-carousel-navigation-right{
	border-left:1px solid #fff;
	width:13px;
}

.schedule-carousel .gelui-carousel-viewport{
	height:82px;
	margin-left:14px;
	width:308px;
}

.schedule-carousel .carousel li,
.schedule-carousel .carousel a{
	display:block;
	margin-bottom:6px;
	padding:29px 10px 13px 10px;
	position:relative;
	_width:22px;
}
.schedule-carousel .carousel a,
.schedule-carousel .carousel a:visited{
	background-color:#f5f5f5;
	color:#1c1c1c;
}
.schedule-carousel .carousel a .day,
.schedule-carousel .carousel a:visited .day,
.schedule-carousel .carousel a .numeric,
.schedule-carousel .carousel a:visited .numeric{
	color:#1c1c1c;
}

.schedule-carousel .carousel li{
	background:#d7d7d7;
	color:#fff;
	border:1px solid #fff;
	border-right:0;
	float:left;
	padding-bottom:8px;
	position:relative;
	height:37px;
	width:23px;
	z-index:2;
}

.schedule-carousel .month,
.schedule-carousel .future .selected .month{
	background:#c8c8c8;
	color:#c8c8c8;
	display:block;
	left:-1px;
	padding:1px 1px 1px 0;
	position:absolute;
	text-align:center;
	top:0;width:43px;
	_width:45px;
	transition:color 1s,border-left-color 1s;
	-webkit-transition:color 1s,border-left-color 1s;
	-ms-transition:color 1s,border-left-color 1s;
	-o-transition:color 1s,border-left-color 1s;
	-moz-transition:color 1s,border-left-color 1s;
	border-bottom:1px solid #fff;
}

.schedule-carousel .carousel a{
	text-decoration:none;
	margin:-29px -10px -13px -10px;
}

.schedule-carousel .carousel a:hover .day,
.schedule-carousel .carousel a:hover .numeric{
	text-decoration:underline;
}

.schedule-carousel .numeric{
	display:block;
	font-size:1.538em;
}

.schedule-carousel .first .month,
.schedule-carousel .carousel .jcarousel-item-first .month{
	color:#4f4b4d;
	text-indent:-2px;
	border-left:1px solid #fff;
}

.schedule-carousel li.today{
	z-index:1;
}

.schedule-carousel .today .selected,
.schedule-carousel .today .selected .day,
.schedule-carousel .today .selected .numeric,
.schedule-carousel .today .selected:visited,
.schedule-carousel .today .selected:visited .day,
.schedule-carousel .today .selected:visited .numeric{
	background-color:#d1700e;
	color:#fff;
}

.schedule-carousel .arrow-background{
	background:#f5f5f5;
	bottom:-9px;*bottom:-7px;
	display:block;
	height:8px;left:0;
	position:absolute;
	width:100%;
}

.schedule-carousel .selected .arrow-background{
	bottom:-8px;
}

.schedule-carousel .arrow{
	border-left:8px solid transparent;
	border-right:8px solid transparent;
	left:14px;
	line-height:0;
	position:absolute;
}

.schedule-carousel .today .selected .arrow{
	border-top:7px solid #d1700e;
}

.schedule-carousel .past .selected .arrow{
	border-top:7px solid #ffe710;
}

.schedule-carousel .future .selected .arrow{
	border-top:7px solid #747474;
}
.schedule-carousel .past .selected,
.schedule-carousel .past .selected:visited,
.schedule-carousel .past a:hover,
.schedule-carousel .past a:focus{
	background-color:#ffe710;
}

.schedule-carousel .future .selected,
.schedule-carousel .future .selected:visited,
.schedule-carousel .future a:hover,
.schedule-carousel .future a:focus{
	background-color:#747474;
	color:#fff;
}

.schedule-carousel .future .selected span,
.schedule-carousel .future .selected:visited span,
.schedule-carousel .future a:hover .day,
.schedule-carousel .future a:hover .numeric,
.schedule-carousel .future a:focus .day,
.schedule-carousel .future a:focus .numeric{
	color:#fff;
}

.today-at-the-games {
    background: #f2f2f2;
    position: relative;
}
.today-at-the-games .session-header {
    background: #747474;
    color: #ffffff;
    font-weight: bold;
    padding: 8px 16px;
}
.today-at-the-games .picks {
    display: block;
    margin: 0 16px;
}
.today-at-the-games tbody {
    display: block;
}
.today-at-the-games .pick {
    border-bottom: 1px solid #dedede;
    display: block;
    display: table-row;
    vertical-align: middle;
}
.today-at-the-games tr {
    height: 30px;
}
.today-at-the-games td {
    padding: 3px;
}
.today-at-the-games .scrollable {
	position: relative;
    height: 186px;
    overflow-y: auto;
    overflow-x: hidden;
	
}
.today-at-the-games .start {
    width: 44px;
}
.today-at-the-games .session {
    width: 115px;
}
.today-at-the-games .status {
    text-align: right;
    width: 110px;
}
.today-at-the-games .more {
    padding: 8px 16px;
}
.today-at-the-games .available-soon {
    color: #4f4d4b;
}

.today-at-the-games .picks a,
.today-at-the-games .picks a:hover,
.today-at-the-games .picks a:visited{
	font-weight: normal;
}


/** SCHEDULE CSS
********************************/
.schedule-button, 
a.schedule-button:visited, 
.schedule-button:visited {
    color: #ffffff;
    background: #4e7a22;
    cursor: pointer;
    display: block;
    margin: 8px 16px;
    padding: 4px 6px;
    -webkit-appearance:none;
}

.schedule-button:hover {
    background: #3d6217;
}

.tg-panel {
    left: 58px;
    position: absolute;
    top: 0;
    width: 226px;
	overflow:visible;
    z-index: 100;
}

.ie .tg-panel, 
.ie7 .tg-panel, 
.ie8 .tg-panel {
    padding: 8px;
	left: 50px;
	margin-top: 8px;
}

.tg-panel .tg-panel-inner {
    background-color: #4f4d4b;
    color: #ffffff;
    padding: 8px;
}

.tg-panel .heading {
    border-bottom: 1px solid #ffffff;
    padding: 0 0 4px 0;
	font-weight: normal;
	color: #FFFFFF;
}

.tg-panel .summary {
    color: #ffffff;
    padding: 4px 0;
}

.tg-panel .tg-panel-arrow {
    border-left: 8px solid transparent;
    border-right: 8px solid transparent;
    border-top: 8px solid #4f4d4b;
    bottom: -8px;
	left: 8px;
    position: absolute;
	line-height: 0;
}

.ie .tg-panel .tg-panel-arrow,
.ie7 .tg-panel .tg-panel-arrow,
.ie8 .tg-panel .tg-panel-arrow {
    bottom: -16px;
	left: 16px;
    z-index: 9999;
}

.ie8 .tg-panel .tg-panel-arrow {
    bottom: 0;
	left: 16px;
    z-index: 9999;
}

#ttd-widget{
	width:336px;
	font-size:13px;
	background-color:#f5f5f5;
}
#main-content #ttd-widget{
	width:336px;
	margin-bottom:32px;
	font-size:13px;
	background-color:#f5f5f5;
}

.gelui-carousel {
    overflow: hidden;
    position: relative;
    width: 100%;
}

.gelui-carousel .gelui-carousel-viewport {
    overflow: hidden;
    position: relative;
}

.gelui-carousel ul, .gelui-carousel ol {
    list-style: none outside none;
    margin: 0;
    padding: 0;
    position: absolute;
    width: 20000px;
}

.gelui-carousel .gelui-carousel-navigation {
    border: 0 none;
    height: 100%;
    margin: 0;
    padding: 0;
    position: absolute;
    top: 0;
    width: 24px;
    z-index: 50;
}

.gelui-carousel .gelui-carousel-navigation-left {
    left: 0;
}

.gelui-carousel .gelui-carousel-navigation legend {
    display: none;
}

.icon-schedule {
    background: url("http://news.bbcimg.co.uk/news/special/2012/newsspec_3887/img/sprite_olympics.png?cachebuster=cb=0000000001") no-repeat scroll -66px -168px transparent;
    height: 16px;
    margin-right: 8px;
    width: 16px;
}

.icon, .icon-external, 
.icon-comments, 
.icon-rss, 
.icon-camera, 
.icon-video-s, 
.icon-audio-s, 
.icon-twitter, 
.icon-facebook, .icon-new {
    display: block;
    float: left;
    overflow: hidden;
    text-indent: -5000px;
}

.schedule-carousel .gelui-carousel .gelui-carousel-button {
    background: url("http://news.bbcimg.co.uk/news/special/2012/newsspec_3887/img/carousel-prev-next-3.png?cachebuster=cb0000000001") no-repeat scroll 0 0 transparent;	
    border: medium none;
    display: block;
    height: 100%;
    text-indent: -9999px;
    width: 14px;
	padding: 0;
    cursor: pointer;
}

.schedule-carousel .gelui-carousel .gelui-carousel-button-disabled, 
.schedule-carousel .gelui-carousel .gelui-carousel-button-disabled:hover {
    cursor: default;
}

.schedule-carousel .gelui-carousel .gelui-carousel-button-prev,
.schedule-carousel .gelui-carousel .gelui-carousel-button-prev:hover {
    background-position: -1769px center;
    background-position: -6px center;
}

.schedule-carousel .gelui-carousel .gelui-carousel-button-next,
.schedule-carousel .gelui-carousel .gelui-carousel-button-next:hover  {
    background-position: -1919px center;
    background-position: -76px center;
}

.schedule-button, a.schedule-button:visited, .schedule-button:visited {
    background: none repeat scroll 0 0 #4E7A22;
    color: #FFFFFF;
    cursor: pointer;
    display: block;
    margin: 0;
    padding: 4px 6px;
}


.schedule-carousel .gelui-carousel .gelui-carousel-navigation-left .gelui-carousel-button-disabled, 
.schedule-carousel .gelui-carousel .gelui-carousel-navigation-left .gelui-carousel-button-disabled:hover {
    background-position: -1829px center;
    background-position: -30px center;
}

.schedule-carousel .gelui-carousel-navigation-right .gelui-carousel-button-disabled, 
.schedule-carousel .gelui-carousel-navigation-right .gelui-carousel-button-disabled:hover {
    background-position: -1829px center;
    background-position: -52px center;
}

.schedule-carousel .gelui-carousel-navigation {
    border-bottom: 1px solid #FFFFFF;
    border-top: 1px solid #FFFFFF;
    height: 74px;
    width: 14px;
}

.gelui-carousel .gelui-carousel-navigation {
    border: 0 none;
    height: 100%;
    margin: 0;
    padding: 0;
    position: absolute;
    top: 0;
    width: 24px;
    z-index: 50;
}

.gelui-carousel .gelui-carousel-navigation-right {
    right: 0;
}

.schedule-carousel .gelui-carousel-navigation {
    border-bottom: 1px solid #FFFFFF;
    border-top: 1px solid #FFFFFF;
    height: 74px;
    width: 14px;
}

.schedule-carousel .gelui-carousel-navigation-right {
    border-left: 1px solid #FFFFFF;
    width: 13px;
}


.schedule-carousel .carousel a {
    text-decoration: none;
}

.schedule-carousel .numeric {
    display: block;
    font-size: 1.538em;
}

.schedule-carousel .carousel a,
.schedule-carousel .carousel a:hover,
.schedule-carousel .carousel a:visited{
	font-weight: normal;
}

.schedule-carousel .today .month {
    border-bottom: 5px solid #D1700E;
	margin-left: 1px;
}



/* catch-up + live */
.schedule-carousel .video-session {
    margin: 0 16px;
    min-height: 24px;
    padding: 16px 0;
    position: relative;
}

.schedule-carousel .video-session-title {
    color: #757374;
    font-size: 0.91em;
	font-weight: normal;
    margin-left: 90px;
    padding: 0;
}

.schedule-carousel .catch-up .video-session-title {
    margin-left: 126px;
}

.schedule-carousel .video-session a, 
.schedule-carousel .video-session p {
    position: absolute;
}

.schedule-carousel .live-link, 
.schedule-carousel .catch-up-link {
    background-color: #0087FF;
    color: #FFFFFF;
    display: inline-block;
    font-weight: bold;
    line-height: 1.89em;
    padding: 0 34px 0 10px;
    position: relative;
    text-transform: uppercase;
}

.schedule-carousel .picks .live-link, 
.schedule-carousel .picks .catch-up-link {
    color: #FFFFFF;
    font-weight: bold;
    line-height: 1.89em;
    text-transform: uppercase;
}
.schedule-carousel .picks .live-link:hover {
    background: none repeat scroll 0 0 #0066C2;
    font-weight: bold;
}
.schedule-carousel .picks .live-link:hover span {
    background-position: -1484px -112px;
}

.schedule-carousel .picks .catch-up-link, 
.schedule-carousel .picks .catch-up-link:hover,
.schedule-carousel .picks .catch-up-link:active, 
.schedule-carousel .picks .catch-up-link:visited {
    background-color: #FFE714;
    color: #3B3604;
    font-weight: bold;
}
.schedule-carousel .catch-up-link, 
.schedule-carousel .catch-up-link:visited {
    color: #3B3604;
}

.schedule-carousel .icon-video, .icon-audio, 
.schedule-carousel .icon-video-live-l, 
.schedule-carousel .icon-video-catch-up-l {
    background: url("http://news.bbcimg.co.uk/news/special/2012/newsspec_3887/img/gvl3_icons_sprite_sport.png?cachebuster=cb0000000001") no-repeat scroll 0 0 transparent;
    height: 24px;
    width: 24px;
}

.schedule-carousel .icon-video-catch-up-l {
    background-position: -1484px -40px;
}
.schedule-carousel .icon-video-live-l {
    background-position: -1484px -76px;
}

.schedule-carousel .live-link .icon-video-live-l, 
.schedule-carousel .catch-up-link .icon-video-catch-up-l {
    border-left: 1px solid #FFFFFF;
    margin-left: 8px;
    position: absolute;
    right: 0;
    top: 0;
}

.blq-js .today-at-the-games .carousel-wrapper { overflow: hidden; }
.today-at-the-games .carousel-wrapper { overflow-x: scroll; }
</style>

2e50
   <div class="mod today-at-the-games schedule-carousel"> <h2 class="heading-plain">Olympics Day Planner</h2> <div class="carousel-wrapper">    <ul class="carousel 1343903373640044034">  <li class="past">  <a href="?date=20120725#schedule-day-20120725">  <span class="day">Wed</span> <span class="numeric">25</span> <span class="month">Jul</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="past">  <a href="?date=20120726#schedule-day-20120726">  <span class="day">Thu</span> <span class="numeric">26</span> <span class="month">Jul</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="past">  <a href="?date=20120727#schedule-day-20120727">  <span class="day">Fri</span> <span class="numeric">27</span> <span class="month">Jul</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="past">  <a href="?date=20120728#schedule-day-20120728">  <span class="day">Sat</span> <span class="numeric">28</span> <span class="month">Jul</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="past">  <a href="?date=20120729#schedule-day-20120729">  <span class="day">Sun</span> <span class="numeric">29</span> <span class="month">Jul</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="past">  <a href="?date=20120730#schedule-day-20120730">  <span class="day">Mon</span> <span class="numeric">30</span> <span class="month">Jul</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="past">  <a href="?date=20120731#schedule-day-20120731">  <span class="day">Tue</span> <span class="numeric">31</span> <span class="month">Jul</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="first past">  <a href="?date=20120801#schedule-day-20120801">  <span class="day">Wed</span> <span class="numeric">01</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="today">  <a href="?date=20120802#schedule-day-20120802" class="selected">  <span class="day">Thu</span> <span class="numeric">02</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="future">  <a href="?date=20120803#schedule-day-20120803">  <span class="day">Fri</span> <span class="numeric">03</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="future">  <a href="?date=20120804#schedule-day-20120804">  <span class="day">Sat</span> <span class="numeric">04</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="future">  <a href="?date=20120805#schedule-day-20120805">  <span class="day">Sun</span> <span class="numeric">05</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="future">  <a href="?date=20120806#schedule-day-20120806">  <span class="day">Mon</span> <span class="numeric">06</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="future">  <a href="?date=20120807#schedule-day-20120807">  <span class="day">Tue</span> <span class="numeric">07</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="future">  <a href="?date=20120808#schedule-day-20120808">  <span class="day">Wed</span> <span class="numeric">08</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="future">  <a href="?date=20120809#schedule-day-20120809">  <span class="day">Thu</span> <span class="numeric">09</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="future">  <a href="?date=20120810#schedule-day-20120810">  <span class="day">Fri</span> <span class="numeric">10</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="future">  <a href="?date=20120811#schedule-day-20120811">  <span class="day">Sat</span> <span class="numeric">11</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  <li class="future">  <a href="?date=20120812#schedule-day-20120812">  <span class="day">Sun</span> <span class="numeric">12</span> <span class="month">Aug</span> <span class="arrow-background"><span class="arrow"></span></span>  </a>  </li>  </ul>     <script type="text/javascript">
        //<![CDATA[
            require(
                {paths: {"sportui": "http://static.bbci.co.uk/sport/ui/1.3.3/modules/sportui"}},
                ['sportui/schedule-carousel'],
                function (scheduleCarousel) {
                    scheduleCarousel.init(
                        {
                            'currentDate': '20120802',
                            'currentTime': '11:29',
                            'container': '.1343903373640044034'
                        }
                    );
                }
            );
        //]]>
    </script>
 </div> <h3 class="heading-small session-header">Picks of the Day</h3> <div class="scrollable"> <table class="picks"> <thead> <tr class="blq-hide"> <th scope="col">Start Time</th> <th scope="col">End Time</th> <th scope="col">Sport</th> <th scope="col">Summary</th> <th scope="col">Live or Catchup</th> </tr> </thead> <tbody> <tr class="pick"> <td class="start">08:55</td> <td class="end blq-hide">16:40</td> <td class="session">  <a href="http://www.bbc.co.uk/sport/olympics/2012/sports/fencing"> Fencing  </a>  </td> <td class="summary blq-hide">Women's Team Foil Quarter-finals</td> <td class="status">  <a href="/sport/olympics/2012/live-video/p00w2zhd" class="live-link">  <span class="icon-video-live-l"></span> live </a>  </td></tr><tr class="pick"> <td class="start">09:25</td> <td class="end blq-hide">12:40</td> <td class="session">  <a href="http://www.bbc.co.uk/sport/olympics/2012/sports/judo"> Judo  </a>  </td> <td class="summary blq-hide">Quarter-finals</td> <td class="status">  <a href="/sport/olympics/2012/live-video/p00w2zpb" class="live-link">  <span class="icon-video-live-l"></span> live </a>  </td></tr><tr class="pick"> <td class="start">09:25</td> <td class="end blq-hide">13:20</td> <td class="session">  <a href="http://www.bbc.co.uk/sport/olympics/2012/sports/rowing"> Rowing  </a>  </td> <td class="summary blq-hide">Finals</td> <td class="status">  <a href="/sport/olympics/2012/live-video/p00w2zpd" class="live-link">  <span class="icon-video-live-l"></span> live </a>  </td></tr><tr class="pick"> <td class="start">12:00</td> <td class="end blq-hide">20:10</td> <td class="session">  <a href="http://www.bbc.co.uk/sport/olympics/2012/sports/tennis"> Tennis  </a>  </td> <td class="summary blq-hide">Men's Quarter-Finals - Murray v Almagro</td> <td class="status">    <a href="/sport/ui/components/atc001-add-to-calendar/add?start=20120802T110000Z&amp;end=20120802T191000Z&amp;description=Watch+the+London+2012+Games+on+the+BBC+Sport+website.%5Cr%5CnDon%27t+miss+the+Tennis+taking+place+on+Thursday+02+August+2012+from+12%3A00+to+20%3A10&amp;summary=Men%27s+Quarter-Finals+-+Murray+v+Almagro+-+Tennis+-+London+2012+-+BBC&amp;name=Tennis+-+02-08-2012+12%3A00">Add to calendar</a>   </td></tr><tr class="pick"> <td class="start">13:25</td> <td class="end blq-hide">17:10</td> <td class="session">  <a href="http://www.bbc.co.uk/sport/olympics/2012/sports/canoe-slalom"> Canoe Slalom  </a>  </td> <td class="summary blq-hide">Finals Men's C2, Women's K1</td> <td class="status">    <a href="/sport/ui/components/atc001-add-to-calendar/add?start=20120802T122500Z&amp;end=20120802T161000Z&amp;description=Watch+the+London+2012+Games+on+the+BBC+Sport+website.%5Cr%5CnDon%27t+miss+the+Canoe+Slalom+taking+place+on+Thursday+02+August+2012+from+13%3A25+to+17%3A10&amp;summary=Finals+Men%27s+C2%2C+Women%27s+K1+-+Canoe+Slalom+-+London+2012+-+BBC&amp;name=Canoe+Slalom+-+02-08-2012+13%3A25">Add to calendar</a>   </td></tr><tr class="pick"> <td class="start">14:55</td> <td class="end blq-hide">16:10</td> <td class="session">  <a href="http://www.bbc.co.uk/sport/olympics/2012/sports/shooting"> Shooting  </a>  </td> <td class="summary blq-hide">Men's Double Trap final</td> <td class="status">    <a href="/sport/ui/components/atc001-add-to-calendar/add?start=20120802T135500Z&amp;end=20120802T151000Z&amp;description=Watch+the+London+2012+Games+on+the+BBC+Sport+website.%5Cr%5CnDon%27t+miss+the+Shooting+taking+place+on+Thursday+02+August+2012+from+14%3A55+to+16%3A10&amp;summary=Men%27s+Double+Trap+final+-+Shooting+-+London+2012+-+BBC&amp;name=Shooting+-+02-08-2012+14%3A55">Add to calendar</a>   </td></tr><tr class="pick"> <td class="start">15:55</td> <td class="end blq-hide">18:45</td> <td class="session">  <a href="http://www.bbc.co.uk/sport/olympics/2012/sports/cycling-track"> Cycling - Track  </a>  </td> <td class="summary blq-hide">Team Sprint</td> <td class="status">    <a href="/sport/ui/components/atc001-add-to-calendar/add?start=20120802T145500Z&amp;end=20120802T174500Z&amp;description=Watch+the+London+2012+Games+on+the+BBC+Sport+website.%5Cr%5CnDon%27t+miss+the+Cycling+-+Track+taking+place+on+Thursday+02+August+2012+from+15%3A55+to+18%3A45&amp;summary=Team+Sprint+-+Cycling+-+Track+-+London+2012+-+BBC&amp;name=Cycling+-+Track+-+02-08-2012+15%3A55">Add to calendar</a>   </td></tr><tr class="pick"> <td class="start">18:50</td> <td class="end blq-hide">22:55</td> <td class="session">  <a href="http://www.bbc.co.uk/sport/olympics/2012/sports/hockey"> Hockey  </a>  </td> <td class="summary blq-hide">Women's pool matches</td> <td class="status">    <a href="/sport/ui/components/atc001-add-to-calendar/add?start=20120802T175000Z&amp;end=20120802T215500Z&amp;description=Watch+the+London+2012+Games+on+the+BBC+Sport+website.%5Cr%5CnDon%27t+miss+the+Hockey+taking+place+on+Thursday+02+August+2012+from+18%3A50+to+22%3A55&amp;summary=Women%27s+pool+matches+-+Hockey+-+London+2012+-+BBC&amp;name=Hockey+-+02-08-2012+18%3A50">Add to calendar</a>   </td></tr><tr class="pick"> <td class="start">19:25</td> <td class="end blq-hide">21:15</td> <td class="session">  <a href="http://www.bbc.co.uk/sport/olympics/2012/sports/swimming"> Swimming  </a>  </td> <td class="summary blq-hide">Finals</td> <td class="status">    <a href="/sport/ui/components/atc001-add-to-calendar/add?start=20120802T182500Z&amp;end=20120802T201500Z&amp;description=Watch+the+London+2012+Games+on+the+BBC+Sport+website.%5Cr%5CnDon%27t+miss+the+Swimming+taking+place+on+Thursday+02+August+2012+from+19%3A25+to+21%3A15&amp;summary=Finals+-+Swimming+-+London+2012+-+BBC&amp;name=Swimming+-+02-08-2012+19%3A25">Add to calendar</a>   </td></tr> </tbody> </table> </div> <a href="/sport/olympics/2012/schedule-results/" class="schedule-button"><span class="icon icon-schedule"></span>Full Olympic Schedule</a> </div>             <script type="text/javascript">
                //<![CDATA[
                    require(
                        {paths: {"sportui": "http://static.bbci.co.uk/sport/ui/1.3.3/modules/sportui"}},
                        ['sportui/today-at-the-games'],
                        function (todayAtTheGames) {
                            todayAtTheGames.init({
                                'container': '.today-at-the-games',
                                'useMock': ""
                            });
                        }
                    );
                //]]>
            </script>
         
4



137

</div>
<script type="text/javascript">$render("special-event-promotion-best-include","special-event-promotion-best-include");</script> 
	
<div id="features-and-analysis" class="container-features-and-analysis">
 		<h2 class="features-header">Features &amp; Analysis</h2>
		
 <ul>
  	


		
	
						
91a

			<!-- Non specific version -->
			
			
							
		<li class="medium-image">

			




	


		




<h3 class=" feature-header">
	<a class="story" rel="published-1343862660194" href="/news/magazine-19063605"><img src="http://news.bbcimg.co.uk/media/images/61947000/jpg/_61947267_nationalanthem_getty.jpg" alt="Two children draped in American flags, with their hands on their hearts" />Anthem secrets</a>

		</h3>

			
							<p>The hidden stories behind national songs 	
				  <span id="dna-comment-count___CPS__19063605" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>
			
							<hr />
					</li>
			
							
		<li class="medium-image">

			




	


		




<h3 class=" feature-header">
	<a class="story" rel="published-1343862369166" href="/news/magazine-19052054"><img src="http://news.bbcimg.co.uk/media/images/61934000/jpg/_61934333_tag_6bnthinkstock.jpg" alt="A price tag with the figure $6bn" />$6bn price tag </a>

		</h3>

			
							<p>Why does the US election cost so very much? 	
				  <span id="dna-comment-count___CPS__19052054" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>
			
							<hr />
					</li>
			
							
		<li class="medium-image">

			




	


		




<h3 class=" feature-header">
	<a class="story" rel="published-1343839300177" href="/news/uk-politics-19085875"><img src="http://news.bbcimg.co.uk/media/images/61964000/jpg/_61964100_61963827.jpg" alt="Boris Johnson" />Highwire act</a>

		</h3>

			
							<p>How does Boris Johnson keep defying political gravity?  	
				  <span id="dna-comment-count___CPS__19085875" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>
			
							<hr />
					</li>
			
							
		<li class="medium-image">

			




	


		




<h3 class=" feature-header">
	<a class="story" rel="published-1343863227050" href="/news/business-19076873"><img src="http://news.bbcimg.co.uk/media/images/61971000/jpg/_61971684_students.jpg" alt="Chinese students in Los Angeles" />Turtles and seaweed</a>

		</h3>

			
							<p> Foreign degrees no longer give graduates advantage in China 	
				  <span id="dna-comment-count___CPS__19076873" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>
			
							<hr />
					</li>
	
	
23
 
	
	


  	


		
	
						
50c

			<!-- Non specific version -->
			
			
							
		<li class="no-image">

			




	


	




<h3 class=" feature-header">
	<a class="story" rel="published-1343833866348" href="/news/uk-19076219">Mood pill</a>

		</h3>

			
							<p>Mark Easton on north/south antidepressant divide 	
				  <span id="dna-comment-count___CPS__19076219" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>
			
					</li>
			
							
		<li class="no-image">

			




	


	




<h3 class=" feature-header">
	<a class="story" rel="published-1343863658717" href="/news/business-18908879">Regulation failure? </a>

		</h3>

			
							<p>HBOS whistleblower hits out at bank regulators  	
				  <span id="dna-comment-count___CPS__18908879" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>
			
					</li>
			
							
		<li class="no-image">

			




	


	




<h3 class=" feature-header">
	<a class="story" rel="published-1343864172706" href="/news/science-environment-19019409">Polar tweets</a>

		</h3>

			
							<p>How social networking has changed life in the Antarctic  	
				  <span id="dna-comment-count___CPS__19019409" class="gvl3-icon gvl3-icon-comment comment-count"></span></p>
			
					</li>
	
	
c7
 
	
	


   </ul>
</div>
<script type="text/javascript">$render("container-features-and-analysis","features-and-analysis");</script> 

	
<div id="promo-best" class="container-promo-best">
	
148b

	
<div id="av-best" class="container-av-best">
	
																
	<div id="av-stories-best" class="av-stories-best">
		
					<h2 class="av-best-header">Watch/Listen</h2>
				
				<div class="list-wrapper">
		  
            		  
		  <ul class="av-best-carousel carousel ">
			  				  					  					  					  




		


		




<li class=" first-child">
	<a class="story" rel="published-1343850469774" href="/news/world-middle-east-19083917"><img src="http://news.bbcimg.co.uk/media/images/61966000/jpg/_61966736_jex_1482483_de32-1.jpg" alt="Syrian rebels lead loyalist to be killed" />Syria rebels kill Assad loyalists<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:58</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343832170739" href="/news/uk-scotland-19081807"><img src="http://news.bbcimg.co.uk/media/images/61956000/jpg/_61956804_kieran_maxwell.jpg" alt="Kieran Maxwell" />Teenager&#039;s new leg: &#039;It&#039;s brilliant&#039;<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:42</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343852877749" href="/news/entertainment-arts-19088163"><img src="http://news.bbcimg.co.uk/media/images/61967000/jpg/_61967374_jex_1482755_de27-1.jpg" alt="A scene from Vertigo" />Vertigo versus Citizen Kane for greatest film<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">02:14</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343803866962" href="/news/uk-england-sussex-19071071"><img src="http://news.bbcimg.co.uk/media/images/61939000/jpg/_61939818_61939660.jpg" alt="Phil Shrimpton" />&#039;Biggest collection&#039; of Beano and Dandy<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:54</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343824951237" href="/news/world-us-canada-19075701"><img src="http://news.bbcimg.co.uk/media/images/61956000/jpg/_61956304_61948248.jpg" alt="Doorman" />Inside New York&#039;s $100m apartment<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:51</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343797453823" href="/newsbeat/19061735"><img src="http://news.bbcimg.co.uk/media/images/61922000/jpg/_61922531_togetherwithcalves.jpg" alt="Emilio and Liz" />What is the price of cheap milk?<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">01:44</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343813512538" href="/news/world-asia-19074719"><img src="http://news.bbcimg.co.uk/media/images/61948000/jpg/_61948802_jex_1482062_de27-1.jpg" alt="Humpback whale" />Dead whale washes up in swimming pool<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span><span class="av-time">00:44</span></a>

		</li>

				  			  				  					  					  




		


		




<li>
	<a class="story" rel="published-1343803550000" href="/today/hi/today/newsid_9741000/9741973.stm"><img src="http://news.bbcimg.co.uk/media/images/61944000/jpg/_61944331_61096380.jpg" alt="Burning building" />How to regenerate riot-hit suburb<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-listen"> Listen</span></span><span class="av-time">04:03</span></a>

		</li>

				  			  		  </ul>
		</div>
		
	</div>

	<script type="text/javascript">$render("av-stories-best","av-stories-best");</script>


	
<div id="av-live-streams" class="av-live-streams">
	
			  	
						
									<ul>
													
				
			<li  class=" first-child" >

				




		


	




<h3 class="has-icon-boxedlive ">
	<a class="story is-live" rel="published-1278944851948" href="/news/10318089">BBC News Channel<span class="gvl3-icon gvl3-icon-boxedlive"> Live</span></a>

		</h3>

			</li>
				  	
				
							
				
			<li >

				




		


	




<h3 class="has-icon-boxedlive ">
	<a class="story is-live" rel="published-1278939939755" href="http://news.bbc.co.uk/1/hi/help/3681938.stm" onclick="javascript: void window.open('http://www.bbc.co.uk/iplayer/console/bbc_radio_five_live', 'BBC', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=512,height=270,left=0,top=0'); return false;">BBC Radio 5 live<span class="gvl3-icon gvl3-icon-boxedlive"> Live</span></a>

		</h3>

			</li>
						</ul>
	</div>
<script type="text/javascript">$render("av-live-streams","av-live-streams");</script>

</div>
<script type="text/javascript">$render("container-av-best","av-best");</script> 
	
b2

</div>
<script type="text/javascript">$render("container-promo-best","promo-best");</script> 
	
<div id="most-popular-promotion" class="container-most-popular-promotion">
	
105

	
<div id="most-popular" class="livestats livestats-tabbed tabbed most-popular">
	
			<h2 class="livestats-header">Most Popular</h2>
	
							
					<h3 class="tab open"><a href="#">Shared</a></h3>
		
		<div class="panel open">
      		<ol>
	      		
35e
<li
  class="first-child ol1">
  <a
    href="http://www.bbc.co.uk/news/technology-19055707"
    class="story">
    <span
      class="livestats-icon livestats-1">1: </span>Today's kids try the Commodore 64</a>
</li>
<li
  class="ol2">
  <a
    href="http://www.bbc.co.uk/news/uk-england-19087826"
    class="story">
    <span
      class="livestats-icon livestats-2">2: </span>Man held after Olympic bus death</a>
</li>
<li
  class="ol3">
  <a
    href="http://www.bbc.co.uk/news/entertainment-arts-19075751"
    class="story">
    <span
      class="livestats-icon livestats-3">3: </span>Gore Vidal: In quotes</a>
</li>
<li
  class="ol5">
  <a
    href="http://www.bbc.co.uk/news/world-us-canada-19087889"
    class="story">
    <span
      class="livestats-icon livestats-5">5: </span>Fast-food chain backed in gay row</a>
</li>
8b

      		</ol>
      	</div>
					
					<h3 class="tab "><a href="#">Read</a></h3>
		
		<div class="panel ">
      		<ol>
	      		
1e4
<li
  class="first-child ol1">
  <a
    href="http://www.bbc.co.uk/news/world-middle-east-17261265"
    class="story">
    <span
      class="livestats-icon livestats-1">1: </span>Analysis: How would Iran respond to an Israeli attack?</a>
</li>
<li
  class="ol2">
  <a
    href="http://www.bbc.co.uk/news/magazine-19077733"
    class="story">
    <span
      class="livestats-icon livestats-2">2: </span>Viewpoint: G4S and the echoes of the East India Company</a>
</li>
92

      		</ol>
      	</div>
					
					<h3 class="tab "><a href="#">Video/Audio</a></h3>
		
		<div class="panel ">
      		<ol>
	      		
b1d
<li
  class="first-child has-icon-watch ol1">
  <a
    href="http://www.bbc.co.uk/news/uk-19059378"
    class="story">
    <span
      class="livestats-icon livestats-1">1: </span>Couple sold fake Olympic tickets <span
      class="gvl3-icon gvl3-icon-watch"> Watch</span></a>
</li>
<li
  class="has-icon-watch ol2">
  <a
    href="http://www.bbc.co.uk/newsbeat/19061735"
    class="story">
    <span
      class="livestats-icon livestats-2">2: </span>What is the price of cheap milk?<span
      class="gvl3-icon gvl3-icon-watch"> Watch</span></a>
</li>
<li
  class="has-icon-watch ol3">
  <a
    href="http://www.bbc.co.uk/news/10318089"
    class="story">
    <span
      class="livestats-icon livestats-3">3: </span>BBC News Channel<span
      class="gvl3-icon gvl3-icon-watch"> Watch</span></a>
</li>
<li
  class="has-icon-watch ol4">
  <a
    href="http://www.bbc.co.uk/today/hi/today/newsid_9741000/9741973.stm"
    class="story">
    <span
      class="livestats-icon livestats-4">4: </span>How to regenerate riot-hit suburb<span
      class="gvl3-icon gvl3-icon-watch"> Watch</span></a>
</li>
<li
  class="has-icon-watch ol5">
  <a
    href="http://www.bbc.co.uk/news/uk-18948053"
    class="story">
    <span
      class="livestats-icon livestats-5">5: </span>Boy dies in Beamish Museum accident<span
      class="gvl3-icon gvl3-icon-watch"> Watch</span></a>
</li>
<li
  class="has-icon-watch ol6">
  <a
    href="http://www.bbc.co.uk/news/uk-england-essex-19079152"
    class="story">
    <span
      class="livestats-icon livestats-6">6: </span>Sister criticises murder speculation<span
      class="gvl3-icon gvl3-icon-watch"> Watch</span></a>
</li>
<li
  class="has-icon-watch ol7">
  <a
    href="http://www.bbc.co.uk/news/video_and_audio/"
    class="story">
    <span
      class="livestats-icon livestats-7">7: </span>BBC News Channel<span
      class="gvl3-icon gvl3-icon-watch"> Watch</span></a>
</li>
<li
  class="has-icon-watch ol8">
  <a
    href="http://www.bbc.co.uk/news/uk-18791805"
    class="story">
    <span
      class="livestats-icon livestats-8">8: </span>Heathrow queue slow hand-clapped<span
      class="gvl3-icon gvl3-icon-watch"> Watch</span></a>
</li>
<li
  class="has-icon-watch ol9">
  <a
    href="http://www.bbc.co.uk/news/technology-19079657"
    class="story">
    <span
      class="livestats-icon livestats-9">9: </span>Why is Hotmail changing its name?<span
      class="gvl3-icon gvl3-icon-watch"> Watch</span></a>
</li>
<li
  class="has-icon-watch ol10">
  <a
    href="http://www.bbc.co.uk/news/world-africa-19082609"
    class="story">
    <span
      class="livestats-icon livestats-10">10: </span>Rare look at an illegal oil refinery<span
      class="gvl3-icon gvl3-icon-watch"> Watch</span></a>
</li>
22

      		</ol>
      	</div>
		
14b

</div>

<script type="text/javascript">$render("most-popular","most-popular");</script>

</div>
<script type="text/javascript">$render("container-most-popular-promotion","most-popular-promotion");</script> 
	<div id="special-event-promotion-best-promo-module-hyper" class="include-only special-event-promotion-best">
    	
26





  <!-- Empty hyperpuff -->

f1

</div>
<script type="text/javascript">$render("special-event-promotion-best-promo-module-hyper","special-event-promotion-best-promo-module-hyper");</script> 
	<div id="market-data-include" class="include-only market-data-include">
    	
c02
<div class="market-data">
<h2><a href="/news/business/market_data/overview/default.stm">Market Data</a></h2>
<p class="mkt-last-updated">Last Updated at 11:29</p>

<table class="mkt-table">
	<tbody>
		<tr class="table-headers">
			<th id="mkt-index">Market index</th>
			<th id="mkt-current">Current value</th>
			<th id="mkt-trend">Trend</th>
			<th id="mkt-var">Variation</th>
			<th id="mkt-percent">% variation</th>
		</tr>
		
		<tr class="mkt-up">
			<td headers="mkt-index" class="mkt-index"><a href="/news/business/market_data/stockmarket/3/default.stm">FTSE 100</a></td>
			<td headers="mkt-current">5742.44</td>
			<td headers="mkt-trend" class="mkt-trend"><span	class="mkt-trend-image">Up</span></td>
			<td headers="mkt-var">29.62</td>
			<td headers="mkt-percent" class="mkt-percent">0.52%</td>
		</tr>
		
		<tr class="mkt-up">
			<td headers="mkt-index" class="mkt-index"><a href="/news/business/market_data/stockmarket/18/default.stm">Dax</a></td>
			<td headers="mkt-current">6798.06</td>
			<td headers="mkt-trend" class="mkt-trend"><span	class="mkt-trend-image">Up</span></td>
			<td headers="mkt-var">43.60</td>
			<td headers="mkt-percent" class="mkt-percent">0.65%</td>
		</tr>
		
		<tr class="mkt-up">
			<td headers="mkt-index" class="mkt-index"><a href="/news/business/market_data/stockmarket/1/default.stm">Cac 40</a></td>
			<td headers="mkt-current">3339.84</td>
			<td headers="mkt-trend" class="mkt-trend"><span	class="mkt-trend-image">Up</span></td>
			<td headers="mkt-var">18.28</td>
			<td headers="mkt-percent" class="mkt-percent">0.55%</td>
		</tr>
		
		<tr class="mkt-down">
			<td headers="mkt-index" class="mkt-index"><a href="/news/business/market_data/stockmarket/2/default.stm">Dow Jones</a></td>
			<td headers="mkt-current">12971.06</td>
			<td headers="mkt-trend" class="mkt-trend"><span	class="mkt-trend-image">Down</span></td>
			<td headers="mkt-var">-37.62</td>
			<td headers="mkt-percent" class="mkt-percent">-0.29%</td>
		</tr>
		
		<tr class="mkt-down">
			<td headers="mkt-index" class="mkt-index"><a href="/news/business/market_data/stockmarket/12122/default.stm">Nasdaq</a></td>
			<td headers="mkt-current">2920.21</td>
			<td headers="mkt-trend" class="mkt-trend"><span	class="mkt-trend-image">Down</span></td>
			<td headers="mkt-var">-19.31</td>
			<td headers="mkt-percent" class="mkt-percent">-0.66%</td>
		</tr>
		
		<tr class="mkt-up">
			<td headers="mkt-index" class="mkt-index"><a href="/news/business/market_data/stockmarket/29954/default.stm">BBC Global 30</a></td>
			<td headers="mkt-current">6376.42</td>
			<td headers="mkt-trend" class="mkt-trend"><span	class="mkt-trend-image">Up</span></td>
			<td headers="mkt-var">13.31</td>
			<td headers="mkt-percent" class="mkt-percent">0.21%</td>
		</tr>
		
	</tbody>
</table>

<div class="mkt-footer">

<p><a href="/news/business/market_data/ticker/markets/default.stm" class="mkt-ticker">Marketwatch ticker</a></p>

<p class="mkt-data-delayed">Data delayed by 15 mins</p>
</div>
</div>

3

	
c0
					
</div>
<script type="text/javascript">$render("market-data-include","market-data-include");</script> 
	<div id="programmes-promotion" class="include-only programmes-promotion">
    	
52





		     <div class="hyperpuff">
	       	             				  	    	  		  
c

						  

89

<div id="container-programme-promotion" class="container-programme-promotion">
			<h2 class="programmes-header">Programmes</h2>
		
	
57

		<a class="iplayer-branding" href="http://www.bbc.co.uk/iplayer/">BBC iPlayer</a>
	
4e


						<div id="data-feed-best" class="include-only data-feed-best">
    	
5a9
<ul><li class="medium-image"><h4 class="programme-header"><a class="story" href="http://www.bbc.co.uk/iplayer/episode/b01lldrc/Panorama_Disabled_or_Faking_It/"><img alt="Panorama: Disabled or Faking It?" src="http://node1.bbcimg.co.uk/iplayer/images/episode/b01lldrc_150_84.jpg"></img>Panorama<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span></a></h4><p>How the government plans to get people claiming disability benefits back into work.</p><hr></hr></li><li class="medium-image"><h4 class="programme-header"><a class="story" href="http://www.bbc.co.uk/iplayer/episode/b01lml50/Click_28_07_2012/"><img alt="Click: 28/07/2012" src="http://node1.bbcimg.co.uk/iplayer/images/episode/b01lml50_150_84.jpg"></img>Click<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span></a></h4><p>Guide to the latest gadgets, websites, games and computer industry news.</p><hr></hr></li><li class="medium-image"><h4 class="programme-header"><a class="story" href="http://www.bbc.co.uk/iplayer/episode/b01ll4gv/Newsnight_31_07_2012/"><img alt="Newsnight: 31/07/2012" src="http://node2.bbcimg.co.uk/iplayer/images/episode/b01ll4gv_150_84.jpg"></img>Newsnight<span class="gvl3-icon-wrapper"><span class="gvl3-icon gvl3-icon-invert-watch"> Watch</span></span></a></h4><p>Can an Olympian be genetically modified? Is anorexia genetic, and so what if it is?</p><hr></hr></li></ul>
df

</div>
<script type="text/javascript">$render("data-feed-best","data-feed-best");</script> 		
	</div>
<script type="text/javascript">$render("container-programmes-promotion","container-programme-promotion");</script>

1a
	
	       	     </div>
	
6d

</div>
<script type="text/javascript">$render("programmes-promotion","programmes-promotion");</script> 
	
3

	
88

</div>
<script type="text/javascript">$render("container-best","best");</script> 

	<!-- END #MAIN-CONTENT & CPS_ASSET_TYPE CLASS: 
31
index -->
	</div>
<!-- END CPS_AUDIENCE CLASS: 
1a
domestic -->
	
</div> 

566
<div id="related-services" class="footer">
   <div id="news-services">
      <h2>Services</h2>  
	   <ul>
         <li id="service-mobile" class="first-child"><a href="http://www.bbc.co.uk/news/10628994"><span class="gvl3-mobile-icon-large services-icon">&nbsp;</span>Mobile</a></li>
         <li id="service-feeds"><a href="/news/help-17655000"><span class="gvl3-connected-tv-icon-large services-icon">&nbsp;</span>Connected TV</a></li>
         <li id="service-podcast"><a href="http://www.bbc.co.uk/news/10628494"><span class="gvl3-feeds-icon-large services-icon">&nbsp;</span>News feeds</a></li>
         <li id="service-alerts"><a href="http://www.bbc.co.uk/news/10628323"><span class="gvl3-alerts-icon-large services-icon">&nbsp;</span>Alerts</a></li>
         <li id="service-email-news"><a href="http://www.bbc.co.uk/news/help/16617948"><span class="gvl3-email-icon-large services-icon">&nbsp;</span>E-mail news</a></li>
      </ul>	  
   </div>
   <div id="news-related-sites">
      <h2>About BBC News</h2>
      <ul>
         <li class="column-1"><a href="http://www.bbc.co.uk/blogs/theeditors/">Editors' blog</a></li>
         <li class="column-1"><a href="http://www.bbc.co.uk/journalism/">BBC College of Journalism</a></li>
         <li class="column-1"><a href="http://www.bbc.co.uk/news/10621655">News sources</a></li>
      </ul>
   </div>
</div>
23

</div><!-- close front-page -->

2



2

	
2

	
12ef


   </div>   <!--[if IE 6]> <div id="blq-ie6-upgrade"> <p> <span>You're using the Internet Explorer 6 browser to view the BBC website. Our site will work much better if you change to a more modern browser. It's free, quick and easy.</span> <a href="http://www.browserchoice.eu/">Find out more <span>about upgrading your browser</span> here&hellip;</a> </p> </div> <![endif]-->  <div id="blq-foot" xml:lang="en-GB" class="blq-rst blq-clearfix blq-foot-transparent blq-foot-text-dark"> <div id="blq-footlinks"> <h2 class="blq-hide">BBC links</h2>       <ul>                    <li class="blq-footlinks-row"> <ul class="blq-footlinks-row-list"> <li><a href="/news/mobile/" id="blq-footer-mobile">Mobile site</a></li><li><a href="http://www.bbc.co.uk/terms/">Terms of Use</a></li><li><a href="http://www.bbc.co.uk/aboutthebbc/">About the BBC</a></li> </ul> </li>                <li class="blq-footlinks-row"> <ul class="blq-footlinks-row-list"> <li><a href="http://www.bbc.co.uk/privacy/">Privacy</a></li><li><a href="http://www.bbc.co.uk/help/">BBC Help</a></li> </ul> </li>                <li class="blq-footlinks-row"> <ul class="blq-footlinks-row-list"> <li><a href="http://www.bbc.co.uk/privacy/bbc-cookies-policy.shtml">Cookies</a></li><li><a href="http://www.bbc.co.uk/accessibility/">Accessibility Help</a></li> </ul> </li>                <li class="blq-footlinks-row"> <ul class="blq-footlinks-row-list"> <li><a href="http://www.bbc.co.uk/guidance/">Parental Guidance</a></li><li><a href="http://news.bbc.co.uk/newswatch/ukfs/hi/feedback/default.stm">Contact Us</a></li> </ul> </li>             </ul> <script type="text/javascript">/*<![CDATA[*/ (function() { var mLink = document.getElementById('blq-footer-mobile'), stick = function() { var d = new Date (); d.setYear(d.getFullYear() + 1); d = d.toUTCString(); window.bbccookies.set('ckps_d=m;domain=.bbc.co.uk;path=/;expires=' + d ); window.bbccookies.set('ckps_d=m;domain=.bbc.com;path=/;expires=' + d ); }; if (mLink) {  if (mLink.addEventListener) { mLink.addEventListener('click', stick, false); } else if (mLink.attachEvent) { mLink.attachEvent('onclick', stick); } } })(); /*]]>*/</script>  </div>  <div id="blq-foot-blocks" class="blq-footer-image-dark"><img src="http://static.bbci.co.uk/frameworks/barlesque/2.8.7/desktop/3.5/img/blocks/dark.png" width="84" height="24" alt="BBC" /></div>  <p id="blq-disclaim"><span id="blq-copy">BBC &copy; 2012</span> <a href="http://www.bbc.co.uk/help/web/links/">The BBC is not responsible for the content of external sites. Read more.</a></p> <div id="blq-obit"><p><strong>This page is best viewed in an up-to-date web browser with style sheets (CSS) enabled. While you will be able to view the content of this page in your current browser, you will not be able to get the full visual experience. Please consider upgrading your browser software or enabling style sheets (CSS) if you are able to do so.</strong></p></div> </div> </div>  </div> </div>  <script type="text/javascript"> if (typeof require !== 'undefined') { require(['istats-1'], function(istats){ istats.track('external', { region: document.getElementById('blq-main') }); istats.track('download', { region: document.getElementById('blq-main') }); }); } </script>  <script type="text/html" id="blq-panel-template-promo"><![CDATA[ <div id="blq-panel-promo" class="blq-masthead-container"></div> ]]></script> <script type="text/html" id="blq-panel-template-more"><![CDATA[ <div id="blq-panel-more" class="blq-masthead-container  blq-clearfix" xml:lang="en-GB" dir="ltr"> <div class="blq-panel-container panel-paneltype-more"> <div class="panel-header"> <h2> <a href="http://www.bbc.co.uk/a-z/">  More&hellip;  </a> </h2>  <a href="http://www.bbc.co.uk/a-z/" class="panel-header-links panel-header-link">Full A-Z<span class="blq-hide"> of BBC sites</span></a>  </div> <div class="panel-component panel-links">       <ul>   <li> <a href="http://www.bbc.co.uk/cbbc/"  >CBBC</a> </li>    <li> <a href="http://www.bbc.co.uk/cbeebies/"  >CBeebies</a> </li>    <li> <a href="http://www.bbc.co.uk/comedy/"  >Comedy</a> </li>   </ul>  <ul>   <li> <a href="http://www.bbc.co.uk/food/"  >Food</a> </li>    <li> <a href="http://www.bbc.co.uk/health/"  >Health</a> </li>    <li> <a href="http://www.bbc.co.uk/history/"  >History</a> </li>   </ul>  <ul>   <li> <a href="http://www.bbc.co.uk/learning/"  >Learning</a> </li>    <li> <a href="http://www.bbc.co.uk/music/"  >Music</a> </li>    <li> <a href="http://www.bbc.co.uk/science/"  >Science</a> </li>   </ul>  <ul>   <li> <a href="http://www.bbc.co.uk/nature/"  >Nature</a> </li>    <li> <a href="http://www.bbc.co.uk/local/"  >Local</a> </li>    <li> <a href="http://www.bbc.co.uk/travelnews/"  >Travel News</a> </li>   </ul>   </div> </div> ]]></script>             <script type="text/javascript"> pulse.init( 'news', false ); </script> 
2

	
1


2


89
<!-- shared/foot -->
<script type="text/javascript">
	bbc.fmtj.common.removeNoScript({});
	bbc.fmtj.common.tabs.createTabs({});
</script>
2


19
<!-- hi/news/foot.inc -->
2


1a
<!-- shared/foot_index -->
2


2a
<!-- #CREAM hi news domestic foot.inc -->

2


1
 
2a


                                      
4

  
2


2


3

	
8

    		
3

	
4
	
	
7

    	
5

   
2


1b

<!-- CPS COMMENT STATUS: 
b
false -->

1


25

<script type="text/javascript" src="
39
http://feeds.bbci.co.uk/modules/comments/getcount/?items=
5b
__CPS__19076219,__CPS__19085875,__CPS__19090898,__CPS__19078948,__CPS__19086404"></script>

16

</body>
</html>


0

