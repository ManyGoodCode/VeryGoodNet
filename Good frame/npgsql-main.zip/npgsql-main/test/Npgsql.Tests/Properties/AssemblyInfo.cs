﻿using NUnit.Framework;

[assembly: Parallelizable(ParallelScope.Children), Timeout(30000)]

