namespace Npgsql;

/// <summary>
/// Options to configure Npgsql's support for OpenTelemetry tracing.
/// Currently no options are available.
/// </summary>
public class NpgsqlTracingOptions
{
}