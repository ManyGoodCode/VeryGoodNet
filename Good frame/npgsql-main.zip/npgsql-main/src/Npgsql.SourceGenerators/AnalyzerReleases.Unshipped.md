### New Rules
Rule ID | Category | Severity | Notes
--------|----------|----------|-------
PGXXXX  | Internal | Error    |
